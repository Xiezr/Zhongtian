/* v89.118 试玩评测驾驶舱 */
/* fork 自 play_strat_600x.js（v89.92 多策略）；禁止手改生成物 —— 改 patch_v89118d_playtest.py。 */
/* ============================================================
 * play_gold_600x.js — v89.91 「旧币流对照推演」驾驶舱
 * （由 play_600x.js 基线 fork；唯一差异 = 新增 GOLD 策略脑：
 *   旧币换批招进化体 / 旧币买经验书喂将 / 用光自由点 / 旧币提速建造·科技·募兵 /
 *   全资源套现。其余段（建造/扩张/里程碑/战斗）与基线逐字一致。）
 * ------------------------------------------------------------
 * 目标：以游戏原生最高速档 600× 实跑 6 现实小时（= 225 游戏年），
 *       由一个「种田流玩家脑」驱动：建造 / 募兵 / 采集 / 基因实验室种田 /
 *       任务 / 门派 / 扩张 / 自动出征 / 战斗观战（一键自动）。
 *
 * 关键口径（与真人游玩一致）：
 *   · 1 tick = 现实 1 秒；每 tick 时间倍率 600×（tickOnce 内读 settings）
 *   · U.now / Date.now 重写为 **SIM 时钟**（+1s/tick）——使「按现实时间节流」
 *     的系统（自动出征 5 分钟、酒馆批次、每日任务、岁贡）与真人 6 小时
 *     在线时一致地流逝
 *   · 地图 seed 固定（20260921）· 天气/掉落等保持真随机（真实游玩）
 *   · 战斗：观战挂起 → 让它在表上自然走数十秒 → 一键自动（真人点「自动战斗」）
 *
 * 用法：node play_gold_600x.js [ticks] [tag]
 *   默认 21600 ticks（6h×600×=225 游戏年）；输出 .workbuddy/tmp/playtest600/<tag>/
 * ============================================================ */
'use strict';
var fs = require('fs');
var path = require('path');
var R = 'E:/Deepseekdb/';

var ARGV = process.argv.slice(2);
var MAXT = Math.max(96, Number(ARGV[0] || 21600));
var TAG  = ARGV[1] || 'main';
var MODE = ARGV[2] || 'gold';   /* gold | buff | equip | all（v89.92 策略开关） */
var OUT  = path.join(R, '.workbuddy/tmp/playtest600', TAG);
fs.mkdirSync(OUT, { recursive: true });
fs.mkdirSync(path.join(OUT, 'checkpoints'), { recursive: true });

/* ---------- 0. SIM 时钟（先捕获原始计时器，再重写 Date.now） ---------- */
var _RealNow = Date.now.bind(Date);
var SIM_START_MS = Date.UTC(2026, 8, 21, 1, 0, 0);   /* 2026-09-21 09:00 +08:00 */
var simMs = SIM_START_MS;
Date.now = function () { return simMs; };
var TZ = 8 * 3600 * 1000;
function simClock() { return new Date(simMs + TZ).toISOString().replace('T', ' ').slice(0, 19); }

var tNow = 0;
var runBuf = [];
function RUN(s) {
  var line = '[sim ' + simClock() + ' | +' + (tNow / 60).toFixed(0) + 'min] ' + s;
  console.log(line); runBuf.push(line);
  if (runBuf.length >= 60) flushRun();
}
function flushRun() { if (runBuf.length) { fs.appendFileSync(path.join(OUT, 'run.log'), runBuf.join('\n') + '\n'); runBuf = []; } }

/* ---------- 1. 环境（DOM 桩）+ 模块加载 ---------- */
eval(fs.readFileSync(path.join(R, '.workbuddy/tmp/smoke_env_head.js'), 'utf8'));
['data', 'state', 'questdata', 'systems', 'domain', 'map', 'battle', 'tactic', 'icons',
 'gicons', 'bitmaps', 'portraits', 'story', 'ui', 'main'].forEach(function (f) {
  require(path.join(R, 'js', f + '.js'));
});
fs.readdirSync(path.join(R, 'story')).filter(function (f) { return /^vol-.*\.js$/.test(f); })
  .forEach(function (f) { try { require(path.join(R, 'story', f)); } catch (e) {} });

var G = global.GAME, DATA = G.DATA, U = G.utils;

/* ---------- 2. 采集器：全量日志 / 错误 / 战报 / 快照 ---------- */
/* v89.118：分类计数 + 不变量违规台账（试玩"发掘漏洞"的两只眼睛） */
var INV = {
  invasionWarn: 0, invasionHeld: 0, invasionBreached: 0, invasionFailBeacon: 0,
  conscriptRuns: 0, captiveConscripted: 0, captivePop: 0, duelMentions: 0,
  sandboxChecked: 0, defReportNoSbx: 0,
  pendingRep: null, slotLast: 0,
  violations: {}, violN: 0,
};
INV.count = function (msg) {
  /* v89.118 加固：标记时直接抓**战报引用**（布尔标记会在下一次脑周期读到别人） */
  function markRep() {
    var rs = (GAME.state && GAME.state.reports) || [];
    INV.pendingRep = rs[0] || null;
  }
  if (msg.indexOf('🔥 烽火：') >= 0) INV.invasionWarn++;
  else if (msg.indexOf('🛡 ') === 0 && msg.indexOf('击退') >= 0) { INV.invasionHeld++; markRep(); }
  else if (msg.indexOf('攻破城门') >= 0) { INV.invasionBreached++; markRep(); }
  else if (msg.indexOf('城门失守但') >= 0) { INV.invasionFailBeacon++; markRep(); }
  if (msg.indexOf('🪶 ') === 0 && msg.indexOf('收编俘虏') >= 0) INV.conscriptRuns++;
  if (msg.indexOf('【斗将】') >= 0) INV.duelMentions++;
};
INV.viol = function (tag, detail) {
  var key = tag + '｜' + String(detail).slice(0, 90);
  if (!INV.violations[key]) {
    INV.violations[key] = { n: 0, first: tNow };
    RUN('🚨 不变量违规：' + key);
  }
  INV.violations[key].n++;
  INV.violN++;
};
var SNAPS = path.join(OUT, 'snapshots.jsonl');
var BATTLES = path.join(OUT, 'battles.jsonl');
var EV = [], EVFLUSHED = 0;
G.onLog = function (msg) {
  EV.push({ t: tNow, gt: (G.state && G.state.world && G.state.world.elapsed) || 0, msg: msg });
  INV.count(msg);
};
function flushEv() {
  if (EV.length) {
    var buf = '';
    for (var i = 0; i < EV.length; i++) buf += JSON.stringify(EV[i]) + '\n';
    fs.appendFileSync(path.join(OUT, 'events.jsonl'), buf);
    EVFLUSHED += EV.length; EV = [];
  }
}
var ERRS = {}, ERRLIST = [], ERRN = 0;
function noteErr(tag, e) {
  ERRN++;
  var m = String((e && e.message) || e);
  var key = tag + ' | ' + m.slice(0, 140);
  if (!ERRS[key]) {
    ERRS[key] = { n: 0, first: tNow };
    if (ERRLIST.length < 300) ERRLIST.push({ tag: tag, msg: m, t: tNow, stack: String((e && e.stack) || '').split('\n').slice(1, 4).join(' | ') });
  }
  ERRS[key].n++;
}
function safeCall(tag, fn) { try { return fn(); } catch (e) { noteErr(tag, e); return null; } }
var SOFT = {};
function noteSoft(tag, msg) {
  var key = tag + '|' + String(msg).slice(0, 90);
  var rec = SOFT[key] || (SOFT[key] = { n: 0, last: -1e9 });
  rec.n++;
  if (tNow - rec.last > 1800 || rec.n <= 2) { rec.last = tNow; RUN('· ' + tag + '：' + msg + (rec.n > 2 ? '（第' + rec.n + '次）' : '')); }
}
/* 低频结构窥探（供分析时确认真实字段名） */
var DUMPED = {};
function dumpOnce(tag, obj, n) {
  if (DUMPED[tag]) return; DUMPED[tag] = 1;
  try { RUN('DUMP[' + tag + '] ' + JSON.stringify(Object.keys(obj || {}).slice(0, n || 40))); } catch (e) { noteErr('dump.' + tag, e); }
}
function fmtNum(v) {
  v = Number(v) || 0;
  if (Math.abs(v) >= 1e8) return (v / 1e8).toFixed(2) + '亿';
  if (Math.abs(v) >= 1e4) return (v / 1e4).toFixed(1) + '万';
  return String(Math.round(v));
}

/* ---------- 3. 建局（固定地图 seed；其余保持真随机） ---------- */
var st = G.newGame({ name: '北辰', cityName: '灰岗', region: '碎垣', mapSeed: 20260921, portraitSeed: 20260921 });
if (!st.map.grid) G.map.generate();
var city0 = st.cities[0];
st.settings.timeScale = 600;
st.settings.autoUpgrade = true;
st.settings.autoResearch = true;
st.settings.battleWatch = true;
st.settings.innAuto = { on: true, min: 'ying' };
st.settings.autoHeal = true;                 /* v89.118：自动治疗入驾驶舱（满旧币即治） */
G.ui = G.ui || {}; G.ui._cityId = city0.id;

var amc = G.autoMarchCfg();
amc.on = true; amc.genId = null; amc.troops = 500; amc.target = 'wild'; amc.maxLevel = 2;
amc.mode = 'raid'; amc.everyMin = 5; amc.radius = 14; amc.dailyMax = 0;

RUN('=== v89.118 600× × 30h 全功能试玩评测（STRAT v1 基座 · MODE=' + MODE + '） ===');
RUN('建局：北辰 · 「灰岗」· 碎垣 · mapSeed=20260921 · 600× · 目标 ' + MAXT + ' tick（' + (MAXT / 96).toFixed(1) + ' 游戏年）');
RUN('城坐标 (' + city0.x + ',' + city0.y + ') · 初始将 ' + st.generals.map(function (g) { return g.name; }).join('、'));
RUN('初始资源 净水/生物质/电能/废钢/旧币各 2 万 · 幸存者 200 · 城外预设 2净化厂 1水培温室 1发电站 1电弧熔炉');

/* ---------- 4. 工具函数 ---------- */
function yNow() { return (st.world.elapsed || 0) / 57600; }
function cellOf(city, bid) {
  for (var i = 0; i < city.cells.length; i++) {
    var c = city.cells[i];
    if (c && c.build && c.build.id === bid) return { idx: i, cell: c };
  }
  return null;
}
function countBuild(city, bid) {
  var n = 0; city.cells.forEach(function (c) { if (c && c.build && c.build.id === bid) n++; });
  return n;
}
function emptyCell(city) {
  for (var i = 0; i < city.cells.length; i++) {
    var c = city.cells[i];
    if (c && !c.build && !c.official) return i;
  }
  return -1;
}
function armyAll(a) { var t = 0; for (var k in (a || {})) t += a[k] || 0; return t; }
function totalArmy() {
  var t = 0;
  st.cities.forEach(function (c) { t += armyAll(c.army); });
  (st.marches || []).forEach(function (m) { t += armyAll(m.army); });
  (G.gatherList() || []).forEach(function (g) { t += armyAll(g.army); });
  return t;
}
function idleGen(skipLord) {
  var out = null;
  (st.generals || []).forEach(function (g) {
    if (out) return;
    if (skipLord && g.isLord) return;
    if (g.status && g.status !== 'idle') return;
    if (G.gatherByGen && G.gatherByGen(g.id)) return;
    out = g;
  });
  return out;
}
function findWildSpot(maxLv, forGather) {
  var c0 = st.cities[0];
  var resOf = (DATA.GATHER && DATA.GATHER.resOf) || {};
  for (var rr = 2; rr <= 14; rr++) {
    for (var dy = -rr; dy <= rr; dy++) {
      for (var dx = -rr; dx <= rr; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
        var x = c0.x + dx, y = c0.y + dy;
        if (x < 3 || y < 3 || x >= DATA.MAP_W - 3 || y >= DATA.MAP_H - 3) continue;
        var tl = G.map.tile(x, y);
        if (!tl || tl.terrain === 'city') continue;
        if (G.map.npcAt(x, y) || G.map.ownCityAt(x, y) || G.map.fortAt(x, y)) continue;
        if (G.map.wildAt(x, y)) continue;   /* v4：已是我方野地（跳过，否则永远命中同一块） */
        if (forGather && !resOf[tl.terrain]) continue;
        var lv = G.map.wildLevelNow(x, y);
        if (lv == null || lv < 1 || lv > maxLv) continue;
        return { x: x, y: y, lv: lv, terrain: tl.terrain };
      }
    }
  }
  return null;
}
/* v3：只采**自家**野地（实测 '需先占领该野地，方可派军采集'） */
function findOwnGatherSpot() {
  var resOf = (DATA.GATHER && DATA.GATHER.resOf) || {};
  var busyList = G.gatherList() || [];
  var best = null;
  (st.wilds || []).forEach(function (w) {
    if (best) return;
    var tl = G.map.tile(w.x, w.y);
    if (!tl || !resOf[tl.terrain]) return;
    var busy = busyList.some(function (g) { return g.x === w.x && g.y === w.y; });
    if (busy) return;
    best = { x: w.x, y: w.y, lv: w.level || 1 };
  });
  return best;
}
/* v4：找一块**无主平原**（筑城用；先占后筑） */
function findPlainSpot() {
  var c0 = st.cities[0];
  for (var rr = 3; rr <= 20; rr++) {
    for (var dy = -rr; dy <= rr; dy++) for (var dx = -rr; dx <= rr; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
      var x = c0.x + dx, y = c0.y + dy;
      if (x < 3 || y < 3 || x >= DATA.MAP_W - 3 || y >= DATA.MAP_H - 3) continue;
      var tl = G.map.tile(x, y);
      if (!tl || tl.terrain !== 'plain') continue;
      if (G.map.wildAt(x, y) || G.map.npcAt(x, y) || G.map.ownCityAt(x, y) || G.map.fortAt(x, y)) continue;
      return { x: x, y: y };
    }
  }
  return null;
}
var MILE_TS = {};
/* 筑城准备：有自家平原 → 直接用；没有 → 遣军占一块平原（带冷却） */
function ensurePlainForCity(tag) {
  var plain = null;
  (st.wilds || []).forEach(function (w) { if (!plain && w.type === 'plain') plain = w; });
  if (plain) return { have: true, w: plain };
  if (tNow - (MILE_TS['occ_' + tag] || 0) < 600) return { have: false };
  var gen = idleGen(true); if (!gen) return { have: false };
  var spot = findPlainSpot(); if (!spot) return { have: false };
  setCity(st.cities[0]);
  var tk = takeArmy(st.cities[0], 400);
  if (tk.total < 280) return { have: false };
  var r = safeCall(tag + '.occ', function () { return G.march.dispatch({ kind: 'wild', x: spot.x, y: spot.y }, 'occupy', tk.army, gen.id); });
  MILE_TS['occ_' + tag] = tNow;
  if (r && r.ok) RUN('🏯 为筑城先占平原 @' + spot.x + ',' + spot.y + '（' + tag + '）');
  if (r && !r.ok) noteSoft(tag + '.occ', r.msg);
  return { have: false };
}
function findFortSpot(maxLv, radius) {
  var c0 = st.cities[0];
  for (var rr = 3; rr <= (radius || 20); rr++) {
    for (var dy = -rr; dy <= rr; dy++) {
      for (var dx = -rr; dx <= rr; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
        var x = c0.x + dx, y = c0.y + dy;
        if (x < 3 || y < 3 || x >= DATA.MAP_W - 3 || y >= DATA.MAP_H - 3) continue;
        var f = G.map.fortAt(x, y);
        if (!f) continue;
        var lvf = (f.level != null ? f.level : f.lv) || 1;
        if (lvf >= 1 && lvf <= maxLv) return { x: x, y: y, lv: lvf, name: f.name };
      }
    }
  }
  return null;
}
function setCity(c) { G.ui._cityId = c.id; }

/* ---------- 5. 玩家脑：各系统动作 ---------- */
/* 5.1 建造（空位 → 关键建筑）*/
var BUILD_PRIO = [
  /* v2：顺序按依赖链修正 —— v1 实测「招贤馆 需酒馆 Lv2」，酒馆必须先建 */
  { bid: 'junying', want: 1 }, { bid: 'shuyuan', want: 1 }, { bid: 'kezhan', want: 1 },
  { bid: 'zhaoxianguan', want: 1 }, { bid: 'cangku', want: 1 }, { bid: 'shichang', want: 1 },
  { bid: 'honglusi', want: 1 }, { bid: 'fenghuotai', want: 1 }, { bid: 'yizhan', want: 1 },
  { bid: 'minfang', want: 8 }, { bid: 'majiu', want: 1 }, { bid: 'tiejiangpu', want: 1 },
  { bid: 'gongjiangzuofang', want: 1 }
];
function tryBuildNew() {
  st.cities.forEach(function (city) {
    var slots = G.buildSlots(city);
    for (var i = 0; i < BUILD_PRIO.length; i++) {
      var it = BUILD_PRIO[i];
      if (countBuild(city, it.bid) >= it.want) continue;
      if (G.buildQueueUsed(city.id) >= slots) return;
      var idx = emptyCell(city);
      if (idx < 0) return;
      setCity(city);
      var r = safeCall('build.' + city.name + '.' + it.bid, function () { return G.buildAt(city.id, idx, it.bid); });
      if (r && r.ok) { RUN('🏗 开建：' + city.name + ' ' + it.bid + ' @格' + idx); continue; }
      if (r && !r.ok) { noteSoft('build.' + city.name + '.' + it.bid, r.msg); continue; }
    }
  });
}
/* 5.2 城外资源地块扩建 */
function tryBuildExt() {
  var city = st.cities[0];
  var grid = G.extGridOf(city) || [];
  var want = { farm: 4, forest: 3, quarry: 3, mine: 3 };
  var cnt = {};
  grid.forEach(function (e) { if (e.type) cnt[e.type] = (cnt[e.type] || 0) + 1; });
  var need = null;
  for (var k in want) { if ((cnt[k] || 0) < want[k]) { need = k; break; } }
  if (!need) return;
  var used = grid.filter(function (e) { return !!e.type; }).length;
  var cap = (G.extCap ? G.extCap(city) : grid.length) || grid.length;
  if (used >= cap) return;
  for (var i = 0; i < grid.length; i++) {
    if (grid[i].type) continue;
    setCity(city);
    var r = safeCall('ext.' + need, function () { return G.buildExt(i, need); });
    if (r && r.ok) { RUN('🌾 城外扩建：' + need + ' @e' + i); }
    if (r && !r.ok) noteSoft('ext.' + need, r.msg);
    return;
  }
}
/* 5.3 围墙 */
function tryWall() {
  var city = st.cities[0];
  /* v89.126 跟随：围墙并入建筑体系，wallPendingOf/buildWall/wallLv 退役 */
  var lv = G.buildingLevel(city, 'chengqiang') || 0;
  if (city.wall && city.wall.pending) return;
  if (lv >= G.buildCapOf(city, 'chengqiang')) return;
  var r = safeCall('wall', function () {
    return lv > 0 ? G.upgradeAt(city.id, 'wall') : G.buildAt(city.id, 'wall', 'chengqiang');
  });
  if (r && r.ok) RUN('🧱 围墙 → Lv' + (lv + 1) + ' 开建');
  if (r && !r.ok) noteSoft('wall', r.msg);
}
/* 5.4 募兵 */
var TROOP_ORDER = ['zhuzhan', 'fujiche', 'buxingji', 'dunwei', 'daodanche'];
function armyTarget() {
  var y = yNow();
  if (y < 0.25) return 300;
  if (y < 1) return 1200;
  if (y < 3) return 5000;
  if (y < 8) return 15000;
  if (y < 20) return 40000;
  if (y < 50) return 100000;
  return 300000;
}
function tryTrain() {
  if ((st.queues.train || []).length >= 4) return;     /* 队列已有 4 批 → 先等 */
  var target = armyTarget(), cur = totalArmy();
  if (cur >= target) return;
  var lack = target - cur;
  st.cities.forEach(function (city) {
    var jy = cellOf(city, 'junying');
    if (!jy) return;
    setCity(city);
    /* v2：从精锐到基础逐个尝试 —— **未解锁的兵种要跳过继续试后面的**
       （v1 在第一个失败处 return —— 永远试不到民兵，五年一兵未募的根因） */
    var lastFail = '';
    for (var i = 0; i < TROOP_ORDER.length; i++) {
      var tid = TROOP_ORDER[i];
      var mc = safeCall('maxTrain.' + tid, function () { return G.maxTrainCount(tid, city.id, jy.idx); });
      var mcn = (typeof mc === 'number') ? mc : Number(mc && (mc.n || mc.count || mc.max) || 0);
      if (!(mcn > 0)) continue;
      var n = Math.min(mcn, Math.max(20, Math.floor(lack)));
      var r = safeCall('train.' + tid, function () { return G.train(tid, n, city.id, jy.idx); });
      if (r && r.ok) { noteSoft('train.ok', '募兵 ' + tid + ' ×' + n); return; }
      if (r && !r.ok) { lastFail = r.msg || ''; continue; }
    }
    if (lastFail) noteSoft('train.fail', lastFail);
  });
}
/* v2：编队取兵 —— 按 prefer 顺序从城内抽 n 名（不超实有） */
function takeArmy(city, n, order) {
  order = order || ['zhuzhan', 'fujiche', 'buxingji', 'dunwei', 'daodanche'];
  var out = {}, need = n;
  order.forEach(function (tid) {
    if (need <= 0) return;
    var have = city.army[tid] || 0;
    var use = Math.min(have, need);
    if (use > 0) { out[tid] = use; need -= use; }
  });
  var tot = 0; for (var k in out) tot += out[k];
  return { army: out, total: tot };
}
/* 5.5 采集 */
var GATHER_LAST = -1e9;
function tryGather() {
  var list = G.gatherList() || [];
  if (list.length >= 3) return;
  if (tNow - GATHER_LAST < 90) return;
  var gen = idleGen(false);
  if (!gen) return;
  var spot = findOwnGatherSpot();
  if (!spot) { noteSoft('gather.spot', '暂无自家野地可采（待占领）'); return; }
  var c0 = st.cities[0];
  setCity(c0);
  var tkG = takeArmy(c0, 300, ['banche', 'buxingji', 'dunwei', 'daodanche', 'fujiche']);
  if (tkG.total < 50) { noteSoft('gather.noarmy', '城内取不出采集兵（清点各兵种）'); return; }
  var army = tkG.army;
  var r = safeCall('gather.dispatch', function () { return G.dispatchGather(spot.x, spot.y, gen.id, army); });
  GATHER_LAST = tNow;
  if (r && r.ok) RUN('🚚 采集队出发：' + gen.name + '（' + spot.terrain + ' Lv' + spot.lv + ' @' + spot.x + ',' + spot.y + '）');
  if (r && !r.ok) noteSoft('gather.dispatch', r.msg);
}
function finishRipeGathers() {
  var list = G.gatherList() || [];
  list.forEach(function (g) {
    var th = (list.length >= 3) ? 8 * 3600 : 21 * 3600;
    if (g.elapsed >= th) {
      var r = safeCall('gather.finish', function () { return G.finishGather(g.id); });
      if (r && r.ok) noteSoft('gather.done', r.msg);
    }
  });
}
/* 5.5b 持续占领**可采地形**野地（采集的前置；v4：平原留给筑城，见 city2/city3） */
var OCCUPY_LAST = -1e9;
function ownedGatherable() {
  var resOf = (DATA.GATHER && DATA.GATHER.resOf) || {};
  return (st.wilds || []).filter(function (w) {
    var tl = G.map.tile(w.x, w.y);
    return tl && resOf[tl.terrain];
  });
}
function keepOccupying() {
  if (ownedGatherable().length >= 3) return;
  if (tNow - OCCUPY_LAST < 240) return;
  if (totalArmy() < 400) return;
  var gen = idleGen(true); if (!gen) return;
  var spot = findWildSpot(4, true);
  if (!spot) return;
  setCity(st.cities[0]);
  var tk = takeArmy(st.cities[0], 400);
  if (tk.total < 280) return;
  var r = safeCall('occupy.auto', function () { return G.march.dispatch({ kind: 'wild', x: spot.x, y: spot.y }, 'occupy', tk.army, gen.id); });
  OCCUPY_LAST = tNow;
  if (r && r.ok) noteSoft('occupy.ok', '占领可采野地 Lv' + spot.lv + '（' + spot.terrain + '）@' + spot.x + ',' + spot.y);
  if (r && !r.ok) noteSoft('occupy.auto', r.msg);
}

/* 5.5c 驻军回城（占领后留守的兵撤回，否则兵力沉在野地） */
var WD_LAST = -1e9;
function tryWithdraw() {
  if (tNow - WD_LAST < 480) return;
  (st.wilds || []).slice().forEach(function (w) {
    if (!w.garrison || !G.wildGarrisonTotal(w.garrison)) return;
    var r = safeCall('withdraw', function () { return G.doWildWithdraw(w.x, w.y); });
    WD_LAST = tNow;
    if (r && r.ok) noteSoft('withdraw.ok', r.msg);
    if (r && !r.ok) noteSoft('withdraw', r.msg);
  });
}

/* 5.5c2 新城增援：以旧城之兵，补新城之虚（transfer 统一行军通道） */
var REINF_LAST = -1e9;
function tryReinforce() {
  if (st.cities.length < 2) return;
  if (tNow - REINF_LAST < 480) return;
  var main = st.cities[0];
  for (var i = 1; i < st.cities.length; i++) {
    var c = st.cities[i];
    if (armyAll(c.army) >= 400) continue;
    if (armyAll(main.army) < 900) return;
    var gen = idleGen(true); if (!gen) return;
    setCity(main);
    var tk = takeArmy(main, 500);
    if (tk.total < 300) return;
    var r = safeCall('reinforce', function () { return G.march.dispatch({ kind: 'owncity', id: c.id }, 'transfer', tk.army, gen.id); });
    REINF_LAST = tNow;
    if (r && r.ok) noteSoft('reinforce.ok', '调兵 ' + tk.total + ' → ' + c.name);
    if (r && !r.ok) noteSoft('reinforce', r.msg);
    return;
  }
}

/* 5.5d 市场售粮换旧币（设计内的旧币入口：粮→旧币，平价恒定 ≈ 1 旧币 / 6.7 粮） */
var SELL_LAST = -1e9;
function tryMarketSell() {
  if (tNow - SELL_LAST < 240) return;
  var gold = st.res.gold || 0;
  if (gold > 150000) return;                 /* 旧币够用就不卖 */
  var grain = st.res.grain || 0;
  if (grain < 900000) return;                /* 先保 60 万粮底 */
  var amount = Math.min(grain - 600000, 800000);
  if (amount < 10000) return;
  var r = safeCall('market.sell', function () { return G.marketSell('grain', amount); });
  SELL_LAST = tNow;
  if (r && r.ok) noteSoft('market.sell', r.msg);
  if (r && !r.ok) noteSoft('market.sellfail', r.msg);
}

/* 5.6 基因实验室种田 */
var FARM_ROT = 0;
function tryFarm() {
  var hr = safeCall('farm.harvestAll', function () { return G.farmHarvestAll(); });
  if (hr && hr.ok) noteSoft('farm.harvest', hr.msg);
  var f = G.farmOf();
  var seedsOrder = ['seed_tianshou', 'seed_hualong', 'seed_xisui', 'seed_yunling', 'seed_fan'];
  var cropsBySeed = {
    seed_fan: ['yunjinsang', 'yusuihua', 'jiaojinteng', 'xipiteng', 'tanxiangshu', 'tieying'],
    seed_yunling: ['yunlingcao'], seed_xisui: ['xisuizhi'],
    seed_hualong: ['hualongshen'], seed_tianshou: ['tianshouguo']
  };
  for (var i = 0; i < f.plots.length; i++) {
    if (f.plots[i]) continue;
    var planted = false;
    for (var s = 0; s < seedsOrder.length; s++) {
      var sid = seedsOrder[s];
      if ((st.items[sid] || 0) > 0) {
        var cr = cropsBySeed[sid];
        FARM_ROT = (FARM_ROT + 1) % cr.length;
        var r = safeCall('farm.plant', function () { return G.farmPlant(i, cr[FARM_ROT]); });
        if (r && r.ok) { planted = true; }
        else if (r && !r.ok) noteSoft('farm.plant', r.msg);
        break;
      }
    }
    if (!planted) break;
  }
}
/* 5.7 游商（种子快购） */
function tryShop() {
  if ((st.items.seed_fan || 0) < 2 && (st.res.gold || 0) > 120000 && G.farmOf().plots.some(function (p) { return !p; })) {
    var r = safeCall('shop.seed', function () { return G.doShopping('seed_fan', 4); });
    if (r && r.ok) noteSoft('shop.seed', r.msg);
    else if (r && !r.ok) noteSoft('shop.seed', r.msg);
  }
}
/* 5.8 门派 */
var SECT_CHORE_MAXED = false;
function trySect() {
  if (!cellOf(st.cities[0], 'honglusi')) return;
  var ss = G.sectState();
  if (!ss.id) {
    if (yNow() >= 0.4) {
      var r = safeCall('sect.join', function () { return G.doSectJoin('muyun'); });
      if (r && r.ok) RUN('☁️ 入派：牧云庄（' + r.msg + '）');
      if (r && !r.ok) noteSoft('sect.join', r.msg);
    }
    return;
  }
  if (!SECT_CHORE_MAXED) {
    var r2 = safeCall('sect.chores', function () { return G.doSectTaskBulk('chores', 8); });
    if (r2 && r2.ok) noteSoft('sect.chores', r2.msg);
    if (r2 && !r2.ok) { SECT_CHORE_MAXED = true; RUN('☁️ 门派杂役今日已满：' + r2.msg); }
  }
  /* 偶尔捐资测试出口（旧币 > 40 万一次） */
  if (!DUMPED.sectDonate && (st.res.gold || 0) > 400000 && yNow() > 2) {
    DUMPED.sectDonate = 1;
    var r3 = safeCall('sect.donate', function () { return G.doSectTask('donate'); });
    if (r3) RUN('☁️ 捐资修葺测试：' + r3.msg);
  }
}
/* 5.9 任务领取 */
function tryQuests() {
  (DATA.QUESTS || []).forEach(function (q) {
    if (st.quests.done[q.id]) return;
    var amt = safeCall('qa.' + q.id, function () { return G.questAmount(q); }) || 0;
    if (amt >= G.questGoal(q)) {
      var r = safeCall('claim.' + q.id, function () { return G.claimQuest(q.id); });
      if (r && r.ok) noteSoft('quest.done', q.title + '（' + r.msg + '）');
    }
  });
  (st.quests.pool || []).slice().forEach(function (e) {
    var def = G.randomQuestDef(e.id);
    if (!def) return;
    var amt = safeCall('rqam.' + e.id, function () { return G.randQuestAmount(e); });
    if (amt != null && amt >= (def.goal || 1)) {
      var r2 = safeCall('claimR.' + e.id, function () { return G.claimRandomQuest(e.id); });
      if (r2 && r2.ok) noteSoft('rquest.done', def.title + '（' + r2.msg + '）');
    }
  });
}
/* 5.10 自动出征管理（借力的将 / 等级 / 兵力） */
function manageAutoMarch() {
  var y = yNow();
  var wantLv = y < 2 ? 2 : y < 5 ? 4 : y < 15 ? 6 : y < 40 ? 7 : 8;
  var wantTroops = y < 0.5 ? 500 : y < 2 ? 2000 : y < 5 ? 5000 : y < 20 ? 10000 : y < 60 ? 20000 : 50000;
  if (amc.maxLevel !== wantLv) amc.maxLevel = wantLv;
  if (amc.troops !== wantTroops) amc.troops = wantTroops;
  var cur = null;
  (st.generals || []).forEach(function (g) { if (g.id === amc.genId) cur = g; });
  if (!cur) {
    var pick = null;
    (st.generals || []).forEach(function (g) {
      if (!pick && !g.isLord && g.status === 'idle') pick = g;
    });
    if (pick) { amc.genId = pick.id; noteSoft('automarch.gen', '自动出征执行将 → ' + pick.name); }
  }
}

/* ============================================================
 * v89.91 GOLD 策略脑（旧币流对照）—— 与种田基线 play_600x.js 的唯一差异
 * ------------------------------------------------------------
 * 老板假说：旧币换批招高资质 → 旧币买经验书升将 → 用光自由点 →
 *           旧币提速（建造/生产/募兵）→ 增长应是指数级。
 * 本段如实实现该策略，全部走游戏既有出口（不新增任何游戏规则）：
 *   goldSell   全资源溢出套现（基线只卖粮）     → GAME.marketSell
 *   goldInn    酒馆花旧币换批直到出进化体           → GAME.innReroll + innAuto（门槛=进化体）
 *   goldBooks  最优档经验书喂「高潜将」         → GAME.doShopping + systems.useItemMany
 *   goldPoints 用光全部自由点                   → GAME.addFreePoint
 *   goldRush   建造/科技队列花旧币立成            → GAME.queueRushPay
 *   goldTrainRush 募兵队列花旧币买时间            → GAME.trainRush
 *   goldGuards 各城守将 = 本城最高治理者        → GAME.assignGeneral
 *   goldHerbs  灵草升档（给高潜将）             → systems.useItem（rank_up 分支）
 *   goldNeigong 守卫修内功（治理 +6/重）        → GAME.doShopping + systems.useItem
 *   goldLord   君主练功 + 突破                  → GAME.doLordTrain / doLordBreak
 * ============================================================ */
var GOLD = {
  version: 'GOLD v1',
  reserve: 300000,                                  /* 旧币保留下限（不动） */
  spends: { inn: 0, books: 0, build: 0, tech: 0, train: 0, neigong: 0 },
  rerolls: 0, recruits: 0, booksUsed: 0,
  salesCount: 0, goldSold: 0, freePts: 0,
  milestones: {}
};
function gml(id, s) { if (GOLD.milestones[id]) return; GOLD.milestones[id] = 1; RUN('🏆 ' + s); }
function maxGenLv() { var m = 0; (st.generals || []).forEach(function (g) { if ((g.level || 1) > m) m = g.level || 1; }); return m; }
function rankIdxOf(g) { return G.rankIndex(G.rankOf(g).id); }
function eliteCount() { var n = 0; (st.generals || []).forEach(function (g) { if (rankIdxOf(g) >= 2) n++; }); return n; }
function richCity() {
  var best = st.cities[0], bg = -1;
  st.cities.forEach(function (c) { var g = G.res(c).gold || 0; if (g > bg) { bg = g; best = c; } });
  setCity(best); return best;
}
function guardNzOf(g) { return Math.round((G.genAttrs(g) || {}).nz || 0); }

/* ---------- ① 全资源溢出套现（粮木石铁，基线只卖粮） ---------- */
var GS_LAST = -1e9;
function goldSell() {
  if (tNow - GS_LAST < 120) return;
  GS_LAST = tNow;
  var buf = { grain: 500000, wood: 250000, stone: 250000, iron: 350000 };
  st.cities.forEach(function (city) {
    setCity(city);
    ['grain', 'wood', 'stone', 'iron'].forEach(function (r) {
      var s0 = (G.res(city)[r] || 0);
      var over = s0 - buf[r];
      if (over < 60000) return;
      var amt = Math.min(over, 5000000);
      var gg = 0; try { gg = G.marketSellGold(r, amt); } catch (e) {}
      var rr = safeCall('gold.sell', function () { return G.marketSell(r, amt); });
      if (rr && rr.ok) { GOLD.salesCount++; GOLD.goldSold += gg; }
      else if (rr && !rr.ok) noteSoft('gold.sellfail', rr.msg);
    });
  });
  richCity();
}

/* ---------- ② 酒馆：花旧币换批 → 自动招进化体 ---------- */
var GI_LAST = -1e9;
function goldInn() {
  if (tNow - GI_LAST < 90) return;
  GI_LAST = tNow;
  var cfg = G.innAutoCfg();
  cfg.on = true;
  cfg.min = (GOLD.recruits < 6 && yNow() < 120) ? 'ying' : 'liang';
  st.cities.slice().sort(function (a, b) { return (G.res(b).gold || 0) - (G.res(a).gold || 0); })
    .forEach(function (city) {
      if ((G.innLevel(city) || 0) < 6) return;        /* 酒馆太低不出货，等升上来 */
      if (G.genFreeOf(city) <= 0) return;
      setCity(city);
      var budget = Math.min((G.res(city).gold || 0) - 200000, 450000);
      var guard = 0;
      while (guard++ < 80) {
        if (G.genFreeOf(city) <= 0) break;
        var cost = G.innRefreshCost();
        if (budget < cost || (G.res(city).gold || 0) < cost + 100000) break;
        var before = (st.stats && st.stats.recruited) || 0;
        var r = safeCall('gold.innReroll', function () { return G.innReroll(); });
        if (!r || !r.ok) { if (r && !r.ok) noteSoft('gold.inn.fail', r.msg); break; }
        GOLD.rerolls++; GOLD.spends.inn += cost; budget -= cost;
        if (((st.stats && st.stats.recruited) || 0) > before) {
          GOLD.recruits++;
          var ng = st.generals[st.generals.length - 1];
          if (ng) {
            noteSoft('gold.recruit', '酒馆录用 ' + ng.name + '（' + G.rankOf(ng).name + '）');
            if (rankIdxOf(ng) >= 2) gml('firstElite', '酒馆录得高资质：' + ng.name + '（' + G.rankOf(ng).name + '）');
          }
        }
      }
    });
  richCity();
}

/* ---------- ③ 经验书：喂「高潜将」（资质优先 → 守将 → 等级） ---------- */
var GB_LAST = -1e9;
function goldBookTarget() {
  var list = (st.generals || []).filter(function (g) { return !g.isLord; });
  list.sort(function (a, b) {
    var ra = rankIdxOf(a), rb = rankIdxOf(b);
    if (ra !== rb) return rb - ra;
    var ga = (a.status === 'guard') ? 1 : 0, gb = (b.status === 'guard') ? 1 : 0;
    if (ga !== gb) return gb - ga;
    return (b.level || 1) - (a.level || 1);
  });
  for (var i = 0; i < list.length; i++) {
    if (rankIdxOf(list[i]) < 1) continue;            /* 凡品不喂 */
    if (G.expBlocked(list[i])) continue;
    return list[i];
  }
  var lord = G.lordGeneralOf ? G.lordGeneralOf() : null;
  if (lord && !G.expBlocked(lord)) return lord;
  return null;
}
function gmlLv(g, lv) {
  [{ l: 60, t: '首位 Lv60' }, { l: 100, t: '首位 Lv100' }, { l: 140, t: '首位 Lv140（进化体满级）' },
   { l: 180, t: '首位 Lv180（觉醒体满级）' }, { l: 240, t: '首位 Lv240（天启体满级）' }].forEach(function (x) {
    if (lv >= x.l) gml('lv' + x.l, x.t + '：' + g.name + '（' + G.rankOf(g).name + '）Lv' + lv);
  });
}
function goldBooks() {
  if (tNow - GB_LAST < 60) return;
  GB_LAST = tNow;
  var tgt = goldBookTarget();
  if (!tgt) return;
  /* 档位按「每旧币经验」效率从高到低；买得起哪档用哪档（大宗优惠口径） */
  var tiers = [['bingsheng', 400000], ['taigong_bingshu', 330000], ['bingxian_yipian', 240000],
    ['mingjiang_xinchuan', 156000], ['dudu_bingfa', 84000], ['jiangjun_zhanlu', 45000]];
  var guard = 0;
  while (guard++ < 60) {
    var rich = richCity();
    var budget = (G.res(rich).gold || 0) - GOLD.reserve;
    if (budget < 45000) break;
    var tier = null;
    for (var i = 0; i < tiers.length; i++) { if (budget >= tiers[i][1]) { tier = tiers[i]; break; } }
    if (!tier) break;
    /* v2 修 bug：**按需购买（一次一本）** —— v1 按预算买 120 本/次，超出目标上限
       的部分全堆进背包（实测终局积压 570 本千古兵圣 = 2.28 亿旧币存货，报表失真）。
       现在：背包有同档存货先用存货；否则买 1 本 → 用 1 本 → 循环。 */
    var use = null;
    var bagN = st.items[tier[0]] || 0;
    if (bagN > 0) {
      use = safeCall('gold.use', function () { return G.systems.useItemMany(tier[0], tgt.id, 1); });
    } else {
      var r = safeCall('gold.buy', function () { return G.doShopping(tier[0], 1); });
      if (!r || !r.ok) { if (r && !r.ok) noteSoft('gold.buyfail', r.msg); break; }
      var bought = r.bought || 0;
      if (bought <= 0) break;
      GOLD.spends.books += tier[1] * bought;
      use = safeCall('gold.use', function () { return G.systems.useItemMany(tier[0], tgt.id, bought); });
    }
    var used = (use && use.count) || 0;
    if (used <= 0) { if (use && !use.ok) noteSoft('gold.usefail', use.msg); break; }
    GOLD.booksUsed += used;
    gmlLv(tgt, tgt.level || 1);
    if (G.expBlocked(tgt)) break;                    /* 到顶 → 下一轮换人 */
  }
}

/* ---------- ④ 自由点：全部用光（守将/高潜 → 治理；其余 → 武力） ---------- */
function goldPoints() {
  var list = (st.generals || []).filter(function (g) { return !g.isLord; });
  list.sort(function (a, b) {
    var ra = rankIdxOf(a), rb = rankIdxOf(b);
    if (ra !== rb) return rb - ra;
    return (b.level || 1) - (a.level || 1);
  });
  var groomed = {}, n = 0;
  for (var i = 0; i < list.length && n < 3; i++) {
    if (list[i].status !== 'guard') { groomed[list[i].id] = 1; n++; }
  }
  (st.generals || []).forEach(function (g) {
    var fp = Math.floor(g.freePts || 0);
    if (fp < 1) return;
    var stat = 'yw';
    if (!g.isLord && (g.status === 'guard' || groomed[g.id])) stat = 'nz';
    var r = safeCall('gold.pts', function () { return G.addFreePoint(g, stat, fp); });
    if (r && r.ok) GOLD.freePts += fp;
  });
}

/* ---------- ⑤ 队列旧币提速（建造 / 科技） ---------- */
function goldRush() {
  var rich = richCity();
  var minKeep = GOLD.reserve + 150000;
  (st.queues.build || []).slice().forEach(function (q) {
    if ((G.res(rich).gold || 0) < minKeep) return;
    var c = 0; try { c = G.queueRushCost(q); } catch (e) {}
    if (!(c > 0)) return;
    var r = safeCall('gold.rush', function () { return G.queueRushPay(q, '工程'); });
    if (r && r.ok) GOLD.spends.build += c;
  });
  var tq = (st.queues.tech || [])[0];
  if (tq && (G.res(rich).gold || 0) >= minKeep) {
    var c2 = 0; try { c2 = G.queueRushCost(tq); } catch (e) {}
    if (c2 > 0) {
      var r2 = safeCall('gold.rusht', function () { return G.queueRushPay(tq, '研究'); });
      if (r2 && r2.ok) GOLD.spends.tech += c2;
    }
  }
}

/* ---------- ⑥ 募兵花旧币买时间（高水位才动 —— 大兵力批次很贵） ---------- */
function goldTrainRush() {
  var rich = richCity();
  var minKeep = GOLD.reserve + 600000;
  st.cities.forEach(function (city) {
    if ((G.res(rich).gold || 0) < minKeep) return;
    var jy = cellOf(city, 'junying');
    if (!jy) return;
    var q = G.trainRunningOf(city.id, jy.idx, 'train');
    if (!q) return;
    var c = 0; try { c = G.trainRushCost(q, 1.0); } catch (e) {}
    if (!(c > 0)) return;
    var r = safeCall('gold.trush', function () { return G.trainRush(city.id, jy.idx, 1.0, 'train'); });
    if (r && r.ok) GOLD.spends.train += c;
  });
}

/* ---------- ⑦ 守将：本城最高治理者（带滞后带，防来回换） ---------- */
function goldGuards() {
  if ((st.generals || []).length < 3) return;
  st.cities.forEach(function (city) {
    var cur = G.guardGeneralOf(city);
    var best = null, bn = -1;
    (G.generalsIn(city) || []).forEach(function (g) {
      if (g.isLord) return;
      var okState = (g.status === 'idle') || (g.status === 'guard' && g.cityId === city.id);
      if (!okState) return;
      var nz = guardNzOf(g) * 1000 + (g.level || 1);
      if (nz > bn) { bn = nz; best = g; }
    });
    if (!best) return;
    if (cur && best.id === cur.id) return;
    var curScore = cur ? (guardNzOf(cur) * 1000 + (cur.level || 1)) : -1;
    if (cur && bn <= curScore + 5000) return;
    var r = safeCall('gold.guard', function () { return G.assignGeneral(best.id, 'guard', city.id); });
    if (r && r.ok) noteSoft('gold.guard', r.msg);
  });
}

/* ---------- ⑧ 灵草升档（基因实验室产；优先给守将/高等级） ---------- */
function goldHerbs() {
  ['tianshouguo', 'hualongshen', 'xisuizhi', 'yunlingcao'].forEach(function (hid) {
    var guard = 0;
    while ((st.items[hid] || 0) > 0 && guard++ < 20) {
      var item = G.systems.itemInfo(hid);
      if (!item) break;
      var tgt = null, bs = -1;
      (st.generals || []).forEach(function (g) {
        if (G.rankOf(g).id !== item.from) return;
        if (g.status === 'march' || g.status === 'gather') return;
        var sc = (g.level || 1) + ((g.status === 'guard') ? 1000 : 0);
        if (sc > bs) { bs = sc; tgt = g; }
      });
      if (!tgt) { noteSoft('gold.herbno', hid + '：无适用资质的英雄（from=' + item.from + '）'); break; }
      var r = safeCall('gold.rankup', function () { return G.systems.useItem(hid, tgt.id); });
      if (!r || !r.ok) { if (r && !r.ok) noteSoft('gold.rankupfail', r.msg); break; }
      gml('rankup1', '🧬 灵草升档：' + r.msg);
    }
  });
}

/* ---------- ⑨ 内功（守卫修尉缭子·治理 +6/重；君主修三略·武力 +6/重） ---------- */
var GNG_LAST = -1e9;
function goldNeigong() {
  if (tNow - GNG_LAST < 300) return;
  GNG_LAST = tNow;
  var pairs = [];
  st.cities.forEach(function (c) { var g = G.guardGeneralOf(c); if (g) pairs.push({ g: g, book: 'book_weiliu', ng: 'weiliu' }); });
  var lord = G.lordGeneralOf ? G.lordGeneralOf() : null;
  if (lord) pairs.push({ g: lord, book: 'book_sanlue', ng: 'sanlue' });
  pairs.forEach(function (p) {
    var g = p.g;
    if (g.ng && g.ng.id && g.ng.id !== p.ng) return; /* 已修他门，不转修 */
    var lv = (g.ng && g.ng.id === p.ng) ? (g.ng.lv || 0) : 0;
    var steps = 0, before = lv;
    while (lv < 10 && steps++ < 12) {
      var rich = richCity();
      if ((G.res(rich).gold || 0) < GOLD.reserve + 100000) break;
      var b = safeCall('gold.ngbuy', function () { return G.doShopping(p.book, 1); });
      if (!b || !b.ok) break;
      GOLD.spends.neigong += 16000;
      var u = safeCall('gold.nguse', function () { return G.systems.useItem(p.book, g.id); });
      if (!u || !u.ok) { if (u && !u.ok) noteSoft('gold.nguse', u.msg); break; }
      lv = (g.ng && g.ng.lv) || 0;
    }
    if (lv > before) noteSoft('gold.ng', '📖 ' + g.name + ' 内功「' + p.ng + '」→ ' + lv + ' 重');
  });
}

/* ---------- ⑩ 君主：练功 + 突破（段顶自动续升） ---------- */
var GL_LAST = -1e9;
function goldLord() {
  var lord = G.lordGeneralOf ? G.lordGeneralOf() : null;
  if (!lord) return;
  if (tNow - GL_LAST >= 120) {
    GL_LAST = tNow;
    if (G.staNow(lord) > DATA.STAMINA.base * 0.4) {
      var r1 = safeCall('gold.lordTrain', function () { return G.doLordTrain(); });
      if (r1 && !r1.ok) noteSoft('gold.lordTrain', r1.msg);
    }
  }
  var need = G.lordCultivNeed(lord);
  if (need != null && (lord.cultiv || 0) >= need) {
    var r2 = safeCall('gold.lordBreak', function () { return G.doLordBreak(); });
    if (r2 && r2.ok) gml('lordBreak' + G.lordBreaksOf(lord), '👑 君主突破：' + r2.msg);
  }
}

/* ---------- ⑪ 状态行 ---------- */
function goldLine() {
  return '💰 旧币流：累卖 ' + fmtNum(GOLD.goldSold) + ' 旧币/' + GOLD.salesCount + ' 笔'
    + ' · 书耗 ' + fmtNum(GOLD.spends.books) + '（' + GOLD.booksUsed + ' 本）'
    + ' · 换批 ' + GOLD.rerolls + ' 次/招 ' + GOLD.recruits + ' 人（进化体 ' + eliteCount() + '）'
    + ' · 提速 建' + fmtNum(GOLD.spends.build) + '/科' + fmtNum(GOLD.spends.tech) + '/兵' + fmtNum(GOLD.spends.train) + '/内功' + fmtNum(GOLD.spends.neigong)
    + ' · 最高将 Lv' + maxGenLv();
}


/* ============================================================
 * v89.92 · 策略脑 A：BUFF（宝物流）
 * ------------------------------------------------------------
 * 探针实证（probe_v8992）：
 *   · 生产类宝物 3,000 旧币 = 产量 +100%，且 prodUntil **从不被消费**
 *     （死字段）→ 永不到期、叠加无上限 —— 游戏内最便宜的旧币→产量出口；
 *   · 符类（治粟+安民+玄德+文曲星）= 守将治理 ×6.56（24h，正常到期）；
 *   · 大役令 = 建造队列 +5（24h）。
 * 本段如实实现这条路线，全部走游戏既有出口（doShopping + useItem），
 * 不新增任何游戏规则。
 * ============================================================ */
var ITEM_PRICE = {}, MAT_PRICE = {};
(DATA.ITEMS || []).forEach(function (x) { if (x.price) ITEM_PRICE[x.id] = x.price * 100; });
(DATA.MATERIALS || []).forEach(function (m) { MAT_PRICE[m.id] = (m.price || 0) * 100; });

var BUFF = { spend: { prod: 0, attr: 0, corvee: 0 }, units: {}, flags: {}, tFirst: null };
/* ① 大役令：建造队列 +5（24h；一次） */
function buffCorvee() {
  if (BUFF.flags.corvee) return;
  var rich = richCity();
  if ((G.res(rich).gold || 0) < GOLD.reserve + 40000) return;
  var b = safeCall('buff.cvBuy', function () { return G.doShopping('corvee5', 1); });
  if (!b || !b.ok) return;
  var u = safeCall('buff.cvUse', function () { return G.systems.useItem('corvee5', null); });
  if (u && u.ok) { BUFF.flags.corvee = 1; BUFF.spend.corvee += 20000; RUN('🎏 大役令：建造队列 → ' + G.buildSlots(rich)); }
}
/* ② 符类：各城守将四符叠加（治理 ×6.56；到期自动续） */
var BA_LAST = -1e9;
var ATTR_FU = [['zhisu', 28000], ['anmin', 20000], ['xuande', 13000], ['wenquxing', 6000]];
function buffAttr() {
  if (tNow - BA_LAST < 240) return;
  BA_LAST = tNow;
  ATTR_FU.forEach(function (pair) {
    var id = pair[0], price = pair[1];
    st.cities.forEach(function (city) {
      var g = G.guardGeneralOf(city);
      if (!g) return;
      var cur = (st.buffs && st.buffs.gens && st.buffs.gens[g.id]) || {};
      if (cur[id] && cur[id].until > U.now()) return;
      var rich = richCity();
      if ((G.res(rich).gold || 0) < price + GOLD.reserve) return;
      var b = safeCall('buff.fuBuy', function () { return G.doShopping(id, 1); });
      if (!b || !b.ok) return;
      var u = safeCall('buff.fuUse', function () { return G.systems.useItem(id, g.id); });
      if (u && u.ok) {
        BUFF.spend.attr += price;
        if (!BUFF.flags['fu' + id]) { BUFF.flags['fu' + id] = 1; RUN('🎏 符类叠起：' + g.name + ' ← ' + (DATA.ITEMS.filter(function (x) { return x.id === id; })[0] || {}).name + '（nz ' + guardNzOf(g) + '）'); }
      }
    });
  });
}
/* ③ 生产宝物：旧币 → 产量 直接兑换（v89.93 修复后：同类只取最强 + 24h 到期）
   —— 脑按游戏规则行动：同类已有**同级或更强**效果就不再买（钱留给别的线）。 */
var BP_LAST = -1e9;
var PROD_FLOOR = 50000;
var PROD_LIST = [['houji', 3000, 200], ['ganjianglu', 3000, 40], ['jumuling', 3000, 40], ['yugongling', 3000, 40], ['taozhu', 5000, 40]];
function prodItemOf(id) {
  var hit = null;
  (DATA.ITEMS || []).forEach(function (x) { if (x.id === id) hit = x; });
  return hit;
}
function buffOkFor(id) {
  /* 返回 true = 值得买（当前无该资源效果，或现存效果弱于本品） */
  var it = prodItemOf(id);
  if (!it) return false;
  var prod = (st.buffs && st.buffs.prod) || {};
  var until = (st.buffs && st.buffs.prodUntil) || {};
  var cur = prod[it.res] || 0;
  var live = (until[it.res] || 0) > U.now();
  return !(live && cur >= (it.eff || 0));
}
function buffProd() {
  if (tNow - BP_LAST < 90) return;
  BP_LAST = tNow;
  var rich = richCity();
  var surplus = (G.res(rich).gold || 0) - PROD_FLOOR;
  if (surplus < 3000) return;
  var budget = Math.min(surplus * 0.55, 3000000);
  PROD_LIST.forEach(function (it) {
    if (budget < it[1]) return;
    if (!buffOkFor(it[0])) return;                   /* v89.93：已有同级/更强 → 不重复买 */
    var n = 1;                                       /* v89.93：买 1 个即可（刷新 24h） */
    var b = safeCall('buff.pbBuy', function () { return G.doShopping(it[0], n); });
    if (!b || !b.ok || !b.bought) return;
    var got = b.bought;
    var u = safeCall('buff.pbUse', function () { return G.systems.useItemMany(it[0], null, got); });
    var used = (u && u.count) || 0;
    BUFF.spend.prod += it[1] * got;
    BUFF.units[it[0]] = (BUFF.units[it[0]] || 0) + used;
    budget -= it[1] * got;
    if (!BUFF.tFirst && used > 0) { BUFF.tFirst = tNow; RUN('🎏 生产宝物线点火：首个「' + it[0] + '」（+100% 产量/个 · 3,000 旧币）'); }
  });
}

/* ============================================================
 * v89.92 · 策略脑 B：EQUIP（装备流）
 * ------------------------------------------------------------
 * 老板假说：「装备拉满 + 强化拉满 → 原始积累会更快？」
 * 本段如实实现这条路线：
 *   铁匠铺升 Lv7 → 买图纸 → 缺材料就买 → 打造 12 件陨锋套
 *   → 熔铸逐级升到 +10 → 整套装到主城守将。
 * 目标套装 = 陨锋套（探针实测：+10 后治理 +861 —— 七套中唯一
 * 能显著抬治理的套装；全成本约 4,004 万旧币）。
 * ============================================================ */
var EQUIP = {
  spend: { bp: 0, mat: 0, craft: 0, enh: 0 },
  crafted: {}, wornCount: 0, wornGen: null,
  tCraft1: null, tCraft12: null, tEnh120: null, tWorn12: null
};
var YT_IDS = null;
function ytIds() {
  if (!YT_IDS) YT_IDS = Object.keys(DATA.EQUIP).filter(function (id) { return DATA.EQUIP[id].set === 'yitian'; });
  return YT_IDS;
}
function forgeCity() {
  var best = null;
  st.cities.forEach(function (c) {
    var lv = G.buildingLevel(c, 'tiejiangpu') || 0;
    if (lv > 0 && (!best || lv > best.lv)) best = { city: c, lv: lv };
  });
  return best;
}
/* ① 铁匠铺专职升级到 Lv7 */
var EF_LAST = -1e9;
function equipForgeUp() {
  if (tNow - EF_LAST < 60) return;
  EF_LAST = tNow;
  var f = forgeCity();
  if (!f || f.lv >= 7) return;
  var city = f.city;
  if (!G.checkBuildSlot(city.id).ok) return;
  var c = cellOf(city, 'tiejiangpu');
  if (!c) return;
  setCity(city);
  var r = safeCall('equip.forgeUp', function () { return G.upgradeAt(city.id, c.idx); });
  if (r && r.ok) { RUN('⚒ 装备流：铁匠铺 → Lv' + (f.lv + 1) + ' 开建'); EF_LAST = tNow + 240; }
  else if (r && !r.ok) noteSoft('equip.forgeUp', r.msg);
}
/* ② 打造（缺材料/图纸先买；每轮一件，大额支出留痕） */
var EC_LAST = -1e9;
function equipCraft() {
  if (tNow - EC_LAST < 60) return;
  EC_LAST = tNow;
  var f = forgeCity();
  if (!f || f.lv < 7) return;
  setCity(f.city);
  var ids = ytIds();
  for (var i = 0; i < ids.length; i++) {
    var id = ids[i];
    if (EQUIP.crafted[id]) continue;
    var cost = G.forgeCost(id) || {}, mats = G.forgeMaterials(id) || {};
    var need = (cost.gold || 0);
    var lacks = [];
    for (var k in mats) {
      var have = st.items[k] || 0;
      if (have < mats[k]) { lacks.push([k, mats[k] - have]); need += (mats[k] - have) * (MAT_PRICE[k] || 0); }
    }
    if (!(st.items.bp_yitian > 0)) need += 32000;
    if ((G.res(f.city).gold || 0) - GOLD.reserve < need) return;   /* 钱不够，等下一轮 */
    for (var li2 = 0; li2 < lacks.length; li2++) {
      var lackRow = lacks[li2];
      var b1 = safeCall('equip.matBuy', function () { return G.doShopping(lackRow[0], lackRow[1]); });
      if (b1 && b1.ok) EQUIP.spend.mat += lackRow[1] * (MAT_PRICE[lackRow[0]] || 0);
    }
    if (!(st.items.bp_yitian > 0)) {
      var b2 = safeCall('equip.bpBuy', function () { return G.doShopping('bp_yitian', 1); });
      if (b2 && b2.ok) EQUIP.spend.bp += 32000;
    }
    var r = safeCall('equip.forge', function () { return G.forge(id); });
    if (r && r.ok) {
      EQUIP.crafted[id] = 1; EQUIP.spend.craft += (cost.gold || 0);
      var cnum = Object.keys(EQUIP.crafted).length;
      if (!EQUIP.tCraft1) { EQUIP.tCraft1 = tNow; RUN('⚒ 装备流：首件打造 ' + r.msg + '（1/12）'); }
      else if (cnum % 4 === 0) RUN('⚒ 装备流：陨锋套进度 ' + cnum + '/12');
      if (cnum >= 12 && !EQUIP.tCraft12) { EQUIP.tCraft12 = tNow; RUN('🏆 装备流：陨锋套 12 件打造完成'); }
    } else if (r && !r.ok) { noteSoft('equip.forge', r.msg); }
    return;   /* 每轮只打造一件 */
  }
}
/* ③ 熔铸 +10（逐级；钱/铁/石够就升一件） */
var EE_LAST = -1e9;
function equipEnhance() {
  if (tNow - EE_LAST < 40) return;
  EE_LAST = tNow;
  var f = forgeCity();
  if (!f || f.lv < 7) return;
  setCity(f.city);
  var ids = ytIds();
  for (var ii = 0; ii < ids.length; ii++) {
    var id = ids[ii];
    var inst = G.eqFind(id);
    if (!inst) continue;
    var lv = G.eqEnhOf(inst);
    if (lv >= 10) continue;
    var c = G.enhCost(inst) || {};
    if ((G.res(f.city).gold || 0) - GOLD.reserve < (c.gold || 0)) return;
    if ((st.res.iron || 0) < (c.iron || 0) || (st.res.stone || 0) < (c.stone || 0)) return;
    var r = safeCall('equip.enh', function () { return G.enhance(inst.u); });
    if (r && r.ok) {
      EQUIP.spend.enh += (c.gold || 0);
      if (G.eqEnhOf(inst) >= 10) {
        var all10 = ytIds().every(function (x) { var i2 = G.eqFind(x); return i2 && G.eqEnhOf(i2) >= 10; });
        RUN('⚒ 熔铸：' + G.eqLabel(inst) + ' 满级（+10）' + (all10 ? ' —— 12 件全部 +10 达成' : ''));
        if (all10 && !EQUIP.tEnh120) EQUIP.tEnh120 = tNow;
      }
      return;
    }
    if (r && !r.ok) noteSoft('equip.enh', r.msg);
  }
}
/* ④ 穿戴：整套装到「主城守将」（守将变更则随迁） */
var EW_LAST = -1e9;
function equipWear() {
  if (tNow - EW_LAST < 120) return;
  EW_LAST = tNow;
  var g = G.guardGeneralOf(st.cities[0]);
  if (!g) {
    var best = null, bn = -1;
    (G.generalsIn(st.cities[0]) || []).forEach(function (x) { var nz = guardNzOf(x); if (nz > bn) { bn = nz; best = x; } });
    if (!best) return;
    safeCall('equip.guard', function () { return G.assignGeneral(best.id, 'guard', st.cities[0].id); });
    g = best;
  }
  var ids = ytIds(), n = 0;
  for (var i = 0; i < ids.length; i++) {
    var id = ids[i];
    var cur = (g.equip || {})[DATA.EQUIP[id].slot];
    var inst = G.eqFind(id);
    if (!inst) continue;
    if (cur && G.eqId(cur) === id && G.eqUidOf(cur) === G.eqUidOf(inst)) { n++; continue; }
    var r = safeCall('equip.wear', function () { return G.systems.equipItem(g.id, inst.u); });
    if (r && r.ok) n++;
  }
  EQUIP.wornCount = n; EQUIP.wornGen = g.name;
  if (n >= 12 && !EQUIP.tWorn12) { EQUIP.tWorn12 = tNow; RUN('🏆 装备流：12 件陨锋套全部上身（' + g.name + '，nz ' + guardNzOf(g) + '，产量 +' + Math.round(G.guardBonus(st.cities[0]).prod * 100) + '%）'); }
}
/* ⑤ 状态行 */
function stratLine() {
  var s = '';
  if (MODE === 'buff' || MODE === 'all') {
    var pf = G.prodFactors('grain', st.cities[0]) || [], fm = 1;
    pf.forEach(function (x) { fm *= (1 + x.d); });
    s += ' · 🎏宝物流：粮因子 ×' + (fm >= 1e4 ? (fm / 1e4).toFixed(2) + '万' : fm.toFixed(1))
      + ' · 犁 ' + (BUFF.units.houji || 0) + ' · 花 ' + fmtNum(BUFF.spend.prod + BUFF.spend.attr + BUFF.spend.corvee);
  }
  if (MODE === 'equip' || MODE === 'all') {
    var f = forgeCity();
    s += ' · ⚒装备流：炉 Lv' + (f ? f.lv : 0) + ' · 造 ' + Object.keys(EQUIP.crafted).length + '/12'
      + ' · 穿 ' + EQUIP.wornCount + '/12 · 花 ' + fmtNum(EQUIP.spend.bp + EQUIP.spend.mat + EQUIP.spend.craft + EQUIP.spend.enh);
  }
  return s;
}

/* ---------- 6. 里程碑（可延后重试） ---------- */
var MILE = [
  { id: 'raid1', at: 240, done: false, retries: 0, fn: function () {
      if (totalArmy() < 280) return 'wait';
      var gen = idleGen(true); if (!gen) return 'wait';
      var spot = findWildSpot(2, false); if (!spot) return 'wait';
      setCity(st.cities[0]);
      var tk1 = takeArmy(st.cities[0], 280);
      if (tk1.total < 120) return 'wait';
      var r = G.march.dispatch({ kind: 'wild', x: spot.x, y: spot.y }, 'raid', tk1.army, gen.id);
      if (r && r.ok) { RUN('⚔️ 首次出征（Lv' + spot.lv + ' 野地 @' + spot.x + ',' + spot.y + '）：' + r.msg); return 'ok'; }
      if (r && !r.ok) { noteSoft('raid1', r.msg); return 'wait'; }
  } },
  { id: 'occupy1', at: 900, done: false, retries: 0, fn: function () {
      if (totalArmy() < 500) return 'wait';
      var gen = idleGen(true); if (!gen) return 'wait';
      var spot = findWildSpot(2, false); if (!spot) return 'wait';
      setCity(st.cities[0]);
      var tk2 = takeArmy(st.cities[0], 600);
      if (tk2.total < 350) return 'wait';
      var r = G.march.dispatch({ kind: 'wild', x: spot.x, y: spot.y }, 'occupy', tk2.army, gen.id);
      if (r && r.ok) { RUN('🚩 首次占领（Lv' + spot.lv + ' 野地 @' + spot.x + ',' + spot.y + '）：' + r.msg); return 'ok'; }
      if (r && !r.ok) { noteSoft('occupy1', r.msg); return 'wait'; }
  } },
  { id: 'fort1', at: 2400, done: false, retries: 0, fn: function () {
      if (totalArmy() < 2500) return 'wait';
      var gen = idleGen(true); if (!gen) return 'wait';
      var spot = findFortSpot(2, 22); if (!spot) return 'wait';
      setCity(st.cities[0]);
      var tk3 = takeArmy(st.cities[0], 2500);
      if (tk3.total < 1200) return 'wait';
      var r = G.march.dispatch({ kind: 'fort', x: spot.x, y: spot.y }, 'raid', tk3.army, gen.id);
      if (r && r.ok) { RUN('🏕 首次攻据点（Lv' + spot.lv + ' ' + spot.name + ' @' + spot.x + ',' + spot.y + '）：' + r.msg); return 'ok'; }
      if (r && !r.ok) { noteSoft('fort1', r.msg); return 'wait'; }
  } },
  { id: 'scout1', at: 2400, done: false, retries: 0, fn: function () {
      var chk = safeCall('scout.train', function () { return G.maxTrainCount('zhencha', st.cities[0].id, (cellOf(st.cities[0], 'junying') || {}).idx); });
      var n = (typeof chk === 'number') ? chk : Number(chk && (chk.n || chk.count || chk.max) || 0);
      if (n <= 0) return 'wait';
      var jy = cellOf(st.cities[0], 'junying');
      setCity(st.cities[0]);
      var c0 = st.cities[0];
      if (!c0.army.zhencha || c0.army.zhencha < 10) {
        var t = safeCall('scout.tr', function () { return G.train('zhencha', 10, c0.id, jy.idx); });
        if (t && !t.ok) { noteSoft('scout.tr', t.msg); return 'wait'; }
      }
      if ((c0.army.zhencha || 0) < 10) return 'wait';
      /* 找最近名城 */
      var npc = null;
      for (var rr = 5; rr <= 30 && !npc; rr++) {
        for (var dy = -rr; dy <= rr && !npc; dy++) for (var dx = -rr; dx <= rr && !npc; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
          var f = G.map.npcAt(c0.x + dx, c0.y + dy);
          if (f) npc = f;
        }
      }
      if (!npc) return 'wait';
      var gen = idleGen(true); if (!gen) return 'wait';
      var r = G.march.dispatch({ kind: 'city', id: npc.id, npc: npc }, 'scout', { zhencha: 10 }, gen.id);
      if (r && r.ok) { RUN('🦅 侦查名城：' + npc.name + '（' + r.msg + '）'); return 'ok'; }
      if (r && !r.ok) { noteSoft('scout1', r.msg); return 'wait'; }
  } },
  { id: 'city2', at: 1400, done: false, retries: 0, fn: function () {
      if (st.cities.length >= 2) return 'ok';
      if (yNow() < 1.2) return 'wait';
      var g2 = ensurePlainForCity('city2');
      if (!g2.have) return 'wait';
      setCity(st.cities[0]);
      var r2r = safeCall('city2', function () { return G.buildCityAt(g2.w.x, g2.w.y); });
      if (r2r && r2r.ok) { RUN('🏯 筑第二城 @' + g2.w.x + ',' + g2.w.y + '：' + r2r.msg); return 'ok'; }
      if (r2r && !r2r.ok) { noteSoft('city2', r2r.msg); return 'wait'; }
      return 'wait';
    } },
  { id: 'fort2', at: 9000, done: false, retries: 0, fn: function () {
      if (totalArmy() < 10000) return 'wait';
      var gen = idleGen(true); if (!gen) return 'wait';
      var spot = findFortSpot(4, 26); if (!spot) return 'wait';
      setCity(st.cities[0]);
      var tk4 = takeArmy(st.cities[0], Math.min(8000, Math.floor(totalArmy() * 0.5)));
      if (tk4.total < 3000) return 'wait';
      var r = G.march.dispatch({ kind: 'fort', x: spot.x, y: spot.y }, 'raid', tk4.army, gen.id);
      if (r && r.ok) { RUN('🏕 攻据点 Lv' + spot.lv + '（' + spot.name + '）：' + r.msg); return 'ok'; }
      if (r && !r.ok) { noteSoft('fort2', r.msg); return 'wait'; }
    } },
  { id: 'city3', at: 4800, done: false, retries: 0, fn: function () {
      if (st.cities.length >= 3) return 'ok';
      var g3 = ensurePlainForCity('city3');
      if (!g3.have) return 'wait';
      setCity(st.cities[0]);
      var r3r = safeCall('city3', function () { return G.buildCityAt(g3.w.x, g3.w.y); });
      if (r3r && r3r.ok) { RUN('🏯 筑第三城 @' + g3.w.x + ',' + g3.w.y + '：' + r3r.msg); return 'ok'; }
      if (r3r && !r3r.ok) { noteSoft('city3', r3r.msg); return 'wait'; }
      return 'wait';
    } },
  { id: 'npcIntel', at: 9600, done: false, retries: 0, fn: function () {
      var c0 = st.cities[0], npc = null;
      for (var rr = 5; rr <= 30 && !npc; rr++) {
        for (var dy = -rr; dy <= rr && !npc; dy++) for (var dx = -rr; dx <= rr && !npc; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
          var f = G.map.npcAt(c0.x + dx, c0.y + dy);
          if (f) npc = f;
        }
      }
      if (!npc) return 'ok';
      var g = null;
      try { g = G.map.fortGarrison ? G.map.fortGarrison(12) : null; } catch (e) {}
      RUN('📋 名城情报：最近名城「' + npc.name + '」（' + (npc.type || '?') + ' · Lv' + (npc.level || '?') + '）· 我方可动员兵力 ' + fmtNum(totalArmy()) + ' · 同级据点守军基准 ' + fmtNum(g));
      return 'ok';
    } },
  { id: 'npcAtk', at: 7200, done: false, retries: 0, fn: function () {
      /* v89.118：门槛 150000 → 20000（30h 试玩实测兵力 12.6 万，旧门槛永远跳过；
         降门槛让试玩**真打一场名城** —— 覆盖斗将 / 名城守将 / 守城沙盘两路）。 */
      if (totalArmy() < 20000) { RUN('📋 名城攻坚评估：兵力 ' + fmtNum(totalArmy()) + ' 不足以挑战名城（跳过实攻，作为内容深度结论）'); return 'ok'; }
      var c0 = st.cities[0], npc = null;
      for (var rr = 5; rr <= 30 && !npc; rr++) {
        for (var dy = -rr; dy <= rr && !npc; dy++) for (var dx = -rr; dx <= rr && !npc; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
          var f = G.map.npcAt(c0.x + dx, c0.y + dy);
          if (f) npc = f;
        }
      }
      if (!npc) return 'ok';
      var gen = idleGen(true); if (!gen) return 'wait';
      setCity(c0);
      var tk5 = takeArmy(c0, Math.floor(totalArmy() * 0.8));
      var r = G.march.dispatch({ kind: 'city', id: npc.id, npc: npc }, 'raid', tk5.army, gen.id);
      if (r && r.ok) { RUN('⚔️ 挑战名城「' + npc.name + '」（全权限实测）：' + r.msg); return 'ok'; }
      if (r && !r.ok) { noteSoft('npcAtk', r.msg); return 'wait'; }
    } }
];
function execMilestones() {
  for (var i = 0; i < MILE.length; i++) {
    var m = MILE[i];
    if (m.done) continue;
    if (tNow < m.at) continue;   /* v3：数组非严格按 at 排序，break 会挡住后面的里程碑 */
    m.retries++;
    var r = safeCall('mile.' + m.id, m.fn);
    if (r === 'ok') { m.done = true; }
    else if (m.retries > 60) { m.done = true; RUN('⏭ 里程碑 ' + m.id + ' 放弃（重试 ' + m.retries + ' 次未达成）'); }
  }
}

/* ---------- 7. 战斗：观战挂起 → 自然走表 → 一键自动 ---------- */
var BATTLE_SEEN = 0;
function handleBattles() {
  (st.battles || []).slice().forEach(function (rec) {
    if (rec.state !== 'live') return;
    rec._seen = (rec._seen || 0) + 1;
    if (rec._seen === 1) {
      BATTLE_SEEN++;
      var tn = rec.target && (rec.target.name || ('(' + rec.target.x + ',' + rec.target.y + ')'));
      if (BATTLE_SEEN <= 30) RUN('⚔ 战斗挂起 #' + BATTLE_SEEN + '：' + tn + ' · ' + rec.modeId + '（观战 60s/回合，稍后一键结算）');
      if (BATTLE_SEEN === 1) dumpOnce('battleRec', rec, 40);
    }
    var enough = rec._seen >= 4 || (rec.round || 0) >= 1;
    if (enough) {
      safeCall('autoBattle', function () { return G.battle.autoBattle(rec.id); });
      var d = G._battleJustDone || {};
      var row = {
        t: tNow, gt: Math.round((st.world.elapsed || 0)), y: +(yNow().toFixed(2)),
        target: (rec.target && (rec.target.name || ('(' + rec.target.x + ',' + rec.target.y + ')'))) || '',
        mode: rec.modeId, rounds: d.rounds, winner: d.winner,
        atkLoss: d.atkLoss, defLoss: d.defLoss, ok: !!d.ok, waited: rec._seen * 10
      };
      fs.appendFileSync(BATTLES, JSON.stringify(row) + '\n');
      if (BATTLE_SEEN <= 80) RUN('⚔ 战果：' + row.target + ' · ' + row.mode + ' · ' + (row.winner === 'atk' ? '胜' : '败') + ' · ' + row.rounds + ' 回合 · 损 ' + row.atkLoss + ' vs 敌损 ' + row.defLoss);
    }
  });
}

/* ---------- 8. 快照 ---------- */
function snapshot() {
  try {
    var o = { t: tNow, y: +(yNow().toFixed(3)), rm: +(tNow / 60).toFixed(1) };
    var res = {}, pop = 0, popCap = 0, army = 0;
    G.RES_KEYS.forEach(function (k) { res[k] = 0; });
    st.cities.forEach(function (c) {
      var Rr = G.res(c) || {};
      G.RES_KEYS.forEach(function (k) { res[k] += (Rr[k] || 0); });
      pop += Rr.pop || 0; popCap += G.maxPopOf(c);
      army += armyAll(c.army);
    });
    o.res = res; o.pop = Math.round(pop); o.popCap = Math.round(popCap);
    o.army = army; o.wounded = Math.round(st.wounded || 0);
    o.marchArmy = 0; (st.marches || []).forEach(function (m) { o.marchArmy += armyAll(m.army); });
    o.marches = (st.marches || []).length;
    o.gathers = (G.gatherList() || []).length;
    o.cities = st.cities.length;
    var bl = {}, wall = {}, ext = {};
    st.cities.forEach(function (c, ci) {
      var tag = ci === 0 ? '' : ('c' + ci + ':');
      var seen = {};
      c.cells.forEach(function (cc) {
        if (!cc || !cc.build) return;
        var id = cc.build.id;
        if (id === 'guanfu' && seen.guanfu) return;
        seen[id] = 1;
        bl[tag + id] = Math.max(bl[tag + id] || 0, cc.build.lvl);
      });
      wall[c.id] = G.buildingLevel(c, 'chengqiang') || 0;
      (G.extGridOf(c) || []).forEach(function (e) { if (e.type) ext[tag + e.type] = (ext[tag + e.type] || 0) + e.lv; });
    });
    o.bl = bl; o.wall = wall; o.ext = ext;
    var tech = {}, ts_ = 0;
    (DATA.TECH || []).forEach(function (t) { var l = st.techs[t.id] || 0; if (l) { tech[t.id] = l; ts_ += l; } });
    o.tech = tech; o.techSum = ts_;
    o.gens = (st.generals || []).length;
    o.genLv = (st.generals || []).reduce(function (s, g) { return s + (g.level || 1); }, 0);
    var ss = G.sectState() || {};
    o.sectRep = Math.round(ss.rep || 0); o.sectId = ss.id || null;
    o.rep = Math.round(st.rep || 0); o.hearts = Math.round(st.hearts || 0);
    o.qDone = Object.keys((st.quests && st.quests.done) || {}).length;
    o.qPool = ((st.quests && st.quests.pool) || []).length;
    o.reports = (st.reports || []).length;
    o.sgPending = (st.sgPending || []).length;
    o.chronicle = (st.chronicle || []).length;
    o.items = Object.keys(st.items || {}).length;
    o.seeds = { fan: st.items.seed_fan || 0, yunling: st.items.seed_yunling || 0, xisui: st.items.seed_xisui || 0, hualong: st.items.seed_hualong || 0, tianshou: st.items.seed_tianshou || 0 };
    o.auto = {
      up: (st.autoState && st.autoState.msg) || '', tech: (st.autoTechState && st.autoTechState.msg) || '',
      march: (st.autoMarchInfo && st.autoMarchInfo.msg) || ''
    };
    try {
      o.stats2 = { trained: (st.stats && st.stats.trained) || 0, wins: (st.stats && st.stats.wins) || 0,
        raid: (st.stats && st.stats.raidCount) || 0, conquer: (st.stats && st.stats.conquer) || 0,
        build: (st.stats && st.stats.buildDone) || 0, tech: (st.stats && st.stats.techDone) || 0,
        recruited: (st.stats && st.stats.recruited) || 0, trades: (st.stats && st.stats.trades) || 0 };
      o.garrison = (st.wilds || []).reduce(function (s2, w) { return s2 + (w.garrison ? G.wildGarrisonTotal(w.garrison) : 0); }, 0);
    } catch (e) {}
    if (tNow % 960 === 0) { try { o.saveBytes = G.savePayload().length; } catch (e) {} }
    if (typeof GOLD !== 'undefined' && GOLD) {
      o.goldState = { rerolls: GOLD.rerolls, recruits: GOLD.recruits, books: GOLD.booksUsed,
        elites: eliteCount(), spend: GOLD.spends, sold: Math.round(GOLD.goldSold),
        sales: GOLD.salesCount, fp: Math.round(GOLD.freePts) };
      o.guards = st.cities.map(function (c) {
        var g = G.guardGeneralOf(c);
        return g ? { c: c.name, n: g.name, r: G.rankOf(g).name, lv: g.level, nz: guardNzOf(g) } : null;
      });
      o.genTop = (st.generals || []).slice().sort(function (a, b) { return (b.level || 1) - (a.level || 1); })
        .slice(0, 6).map(function (g) {
          var a = G.genAttrs(g) || {};
          return { n: g.name, r: G.rankOf(g).name, lv: g.level || 1,
            nz: Math.round(a.nz || 0), yw: Math.round(a.yw || 0), zm: Math.round(a.zm || 0),
            f: Math.round(g.freePts || 0) };
        });
      var ph = { grain: 0, wood: 0, stone: 0, iron: 0 };
      st.cities.forEach(function (c) { var ps = G.cityProdPerSec(c) || {}; for (var kk in ph) ph[kk] += (ps[kk] || 0); });
      o.prodH = { grain: Math.round(ph.grain * 3600), wood: Math.round(ph.wood * 3600) };
    }
    if (MODE === 'buff' || MODE === 'all') {
      var pf2 = G.prodFactors('grain', st.cities[0]) || [], fm2 = 1;
      pf2.forEach(function (x) { fm2 *= (1 + x.d); });
      o.buff = { grainMult: +fm2.toFixed(2), units: { houji: BUFF.units.houji || 0, taozhu: BUFF.units.taozhu || 0 },
        spend: { prod: Math.round(BUFF.spend.prod), attr: Math.round(BUFF.spend.attr), corvee: Math.round(BUFF.spend.corvee) },
        gnz: (function () { var gg = G.guardGeneralOf(st.cities[0]); return gg ? guardNzOf(gg) : 0; })() };
    }
    if (MODE === 'equip' || MODE === 'all') {
      var fE = forgeCity();
      o.equip = { forge: fE ? fE.lv : 0, crafted: Object.keys(EQUIP.crafted).length, worn: EQUIP.wornCount,
        enhSum: ytIds().reduce(function (a2, x) { var i3 = G.eqFind(x); return a2 + (i3 ? G.eqEnhOf(i3) : 0); }, 0),
        spend: Math.round(EQUIP.spend.bp + EQUIP.spend.mat + EQUIP.spend.craft + EQUIP.spend.enh),
        gnz: (function () { var gg = G.guardGeneralOf(st.cities[0]); return gg ? guardNzOf(gg) : 0; })() };
    }
    fs.appendFileSync(SNAPS, JSON.stringify(o) + '\n');
  } catch (e) { noteErr('snapshot', e); }
}

/* ---------- 8.5 v89.118：新功能驱动 + 不变量体检 + 视图体检 ---------- */
function driveV89118() {
  /* ① 俘虏收编（新口径：收编那一刻才加幸存者，增量 = 兵种 pop 折算）——
        顺手核对"执行侧幸存者增量"与"返回的 pop 字段"是否同源。 */
  var cn = G.captivesTotalOf ? G.captivesTotalOf() : 0;
  if (cn >= 300) {
    var popB = 0;
    st.cities.forEach(function (c) { popB += (G.res(c).pop || 0); });
    var r = null;
    try { r = G.doConscriptCaptives(); } catch (e) { noteErr('conscript', e); }
    if (r && r.ok) {
      INV.conscriptRuns++;
      INV.captiveConscripted += r.n;
      INV.captivePop += r.pop;
      var popA = 0;
      st.cities.forEach(function (c) { popA += (G.res(c).pop || 0); });
      if (Math.abs((popA - popB) - r.pop) > 1) {
        INV.viol('conscript-pop-mismatch', '实际Δ=' + Math.round(popA - popB) + ' 报=' + r.pop);
      }
      RUN('🪶 v89.118：收编 ' + r.n + ' 众 → 幸存者 +' + r.pop + '（口径核对 Δ=' + Math.round(popA - popB) + '）');
    }
  }
  /* ② 战报沙盘 verify（v89.118 加固：核的是**标记时那条战报的引用**）——
        违规消息带 hist/sim 明细，真出问题一眼定位（错位假阳性已排除）。 */
  if (INV.pendingRep) {
    var rep0 = INV.pendingRep;
    INV.pendingRep = null;
    if (rep0 && (st.reports || []).indexOf(rep0) >= 0) {
      if (rep0.sandbox) {
        var sb = null;
        try { sb = G.battle.sandboxOf ? G.battle.sandboxOf(rep0) : null; } catch (e) { noteErr('sandboxOf', e); }
        if (sb && sb.verify === false) {
          var hR = rep0.sandbox.result || {};
          INV.viol('sandbox-verify-false', String(rep0.title || '').slice(0, 26)
            + '｜hist ' + hR.rounds + '/' + hR.atkLoss + '/' + hR.defLoss
            + '｜sim ' + sb.sim.rounds + '/' + sb.sim.atkLoss + '/' + sb.sim.defLoss);
        } else if (sb) INV.sandboxChecked++;
        else INV.defReportNoSbx++;
      } else {
        /* 没配方的战报 —— 记数（未列阵/空城计等路径可能确实无沙盘，不算违规） */
        INV.defReportNoSbx++;
      }
    }
  }
  /* ③ 晋爵（v89.118 补驱动）：领地上限 = 下一档爵位门槛（v89.108）——
        不晋爵就扩不动：旧驾驶舱因此整场停在 2 城（实测）。 */
  if (tNow - (INV.lastPromoteAt || -1e9) >= 240) {
    INV.lastPromoteAt = tNow;
    var pr = null;
    try { pr = G.systems.promote(); } catch (e3) { noteErr('promote', e3); }
    if (pr && pr.ok) {
      INV.promotes = (INV.promotes || 0) + 1;
      RUN('🏅 晋爵：' + pr.msg + '（领地上限 ' + G.cityCapOf() + ' 座）');
    } else if (pr && !pr.ok && !INV.promoteMsg) {
      INV.promoteMsg = String(pr.msg || '');          /* 首次记录原因（分析用） */
    }
  }
  /* ④ 扩张（v89.118 补驱动）：有爵位空间就找平原建新城 —— 覆盖多城路径。
        搜索半径外扩到 48 格（默认 3~20 在 30h 实测没找到空平原 → 卡 2 城）。 */
  if (tNow - (INV.lastExpandAt || -1e9) >= 480) {
    INV.lastExpandAt = tNow;
    var capE = G.cityCapOf ? G.cityCapOf() : 0;
    if ((st.cities || []).length < capE) {
      var spotE = null;
      var c0E = st.cities[0];
      for (var rrE = 3; rrE <= 48 && !spotE; rrE++) {
        for (var dyE = -rrE; dyE <= rrE && !spotE; dyE++) for (var dxE = -rrE; dxE <= rrE && !spotE; dxE++) {
          if (Math.max(Math.abs(dxE), Math.abs(dyE)) !== rrE) continue;
          var xE = c0E.x + dxE, yE = c0E.y + dyE;
          if (xE < 3 || yE < 3 || xE >= DATA.MAP_W - 3 || yE >= DATA.MAP_H - 3) continue;
          var tlE = G.map.tile(xE, yE);
          if (!tlE || tlE.terrain !== 'plain') continue;
          if (G.map.wildAt(xE, yE) || G.map.npcAt(xE, yE) || G.map.ownCityAt(xE, yE) || G.map.fortAt(xE, yE)) continue;
          spotE = { x: xE, y: yE };
        }
      }
      if (spotE) {
        var reE = null;
        try { reE = G.buildCityAt(spotE.x, spotE.y); } catch (e4) { noteErr('expand', e4); }
        if (reE && reE.ok) RUN('🏙 建新城：' + (reE.msg || '') + '（城 ' + st.cities.length + '/' + capE + '）');
        else if (reE && !INV.expandMsg) INV.expandMsg = String(reE.msg || '(无 msg)');
      } else if (!INV.expandMsg) {
        INV.expandMsg = '半径 48 格内无空闲平原（cap=' + capE + '，城=' + st.cities.length + '）';
      }
    }
  }
  /* ④b 名城攻坚（v89.118 补驱动）：兵力够且有闲将 → 打最近名城。
        覆盖：斗将（双方有将才触发）/ 名城守将 / 出征沙盘与守城沙盘两路。 */
  if (!INV.npcAtkDone && tNow - (INV.lastNpcAtkAt || -1e9) >= 2400) {
    INV.lastNpcAtkAt = tNow;
    if (totalArmy() >= 20000) {
      var c0N = st.cities[0], npcN = null;
      for (var rrN = 5; rrN <= 30 && !npcN; rrN++) {
        for (var dyN = -rrN; dyN <= rrN && !npcN; dyN++) for (var dxN = -rrN; dxN <= rrN && !npcN; dxN++) {
          if (Math.max(Math.abs(dxN), Math.abs(dyN)) !== rrN) continue;
          var fN = G.map.npcAt(c0N.x + dxN, c0N.y + dyN);
          if (fN) npcN = fN;
        }
      }
      if (npcN) {
        var genN = idleGen(true);
        if (genN) {
          setCity(c0N);
          var tkN = takeArmy(c0N, Math.floor(totalArmy() * 0.6));
          var rN = safeCall('npcAtk118', function () {
            return G.march.dispatch({ kind: 'city', id: npcN.id, npc: npcN }, 'raid', tkN.army, genN.id);
          });
          if (rN && rN.ok) {
            INV.npcAtkDone = 1;
            RUN('⚔️ v89.118 名城攻坚「' + npcN.name + '」：' + rN.msg + '（兵力 ' + fmtNum(tkN.total) + '）');
          } else if (rN && !rN.ok && !INV.npcAtkMsg) {
            INV.npcAtkMsg = String(rN.msg || '');
          }
        }
      } else if (!INV.npcAtkMsg) {
        INV.npcAtkMsg = '30 格内无名城';
      }
    } else if (!INV.npcAtkMsg) {
      INV.npcAtkMsg = '兵力未达 20000（当前 ' + fmtNum(totalArmy()) + '）';
    }
  }
  /* ⑤ 来犯排期推进（只记进度，供收尾对账） */
  var slotNow = G.invasionSlotOf ? G.invasionSlotOf(G.realNow()) : 0;
  if (slotNow > INV.slotLast) INV.slotLast = slotNow;
}

function checkInvariants() {
  var RESK = ['grain', 'wood', 'stone', 'iron', 'gold'];
  var OKS = { idle: 1, march: 1, gather: 1, mayor: 1, guard: 1 };
  st.cities.forEach(function (c) {
    var R2 = G.res(c);
    RESK.forEach(function (k2) {
      var v = R2[k2];
      if (!isFinite(v)) INV.viol('res-nan', c.name + '.' + k2 + '=' + v);
      else if (v < -1) INV.viol('res-negative', c.name + '.' + k2 + '=' + Math.round(v));
    });
    if (!isFinite(R2.pop) || R2.pop < 0) INV.viol('pop-bad', c.name + ' pop=' + R2.pop);
    for (var k in (c.army || {})) {
      var n = c.army[k];
      if (!isFinite(n) || n < 0) INV.viol('army-bad', c.name + '.' + k + '=' + n);
      if (!G.DATA.TROOPS[k]) INV.viol('army-unknown', k);
    }
    (c.cells || []).forEach(function (cl, ci) {
      if (cl && cl.pending && cl.pending.until && cl.pending.until < st.world.elapsed - 86400 * 3) {
        INV.viol('build-stuck', c.name + ' cell#' + ci);
      }
    });
  });
  (st.generals || []).forEach(function (g) {
    var s2 = g.status || 'idle';
    if (!OKS[s2]) INV.viol('gen-status', g.name + '=' + s2);
    if (!isFinite(g.level) || (g.level || 0) < 0) INV.viol('gen-lv', g.name + '=' + g.level);
  });
  (st.marches || []).forEach(function (m) {
    if (m.totalTime && m.elapsed > m.totalTime * 3 + 600) {
      INV.viol('march-stuck', (m.target && m.target.name) || '?');
    }
  });
  if ((st.reports || []).length > (G.DATA.REPORT_MAX || 60) + 2) {
    INV.viol('report-overflow', st.reports.length);
  }
  var cn2 = G.captivesTotalOf ? G.captivesTotalOf() : 0;
  if (!isFinite(cn2) || cn2 < 0) INV.viol('captive-bad', cn2);
  if (!isFinite(st.wounded || 0) || (st.wounded || 0) < 0) INV.viol('wounded-bad', st.wounded);
  if (!st.cities.length) INV.viol('no-city', '');
  (st.reports || []).slice(0, 8).forEach(function (rp) {
    var tx = String(rp.body || '') + String((rp.loot || []).join(''));
    var m2 = tx.match(/NaN|undefined|Infinity/);
    if (m2) INV.viol('report-text', String(rp.title || '').slice(0, 20) + ' 含 ' + m2[0]);
  });
}

function checkViews() {
  var LIST = [
    ['cityHTML', 'cityHTML'], ['extHTML', 'extHTML'], ['troopsHTML', 'troopsHTML'],
    ['generalsHTML', 'generalsHTML'], ['marchesHTML', 'marchesHTML'], ['equipHTML', 'equipHTML'],
    ['techHTML', 'techHTML'], ['itemsHTML', 'itemsHTML'], ['rankHTML', 'rankHTML'],
    ['mapHTML', 'mapHTML'], ['shopHTML', 'shopHTML'], ['bagHTML', 'bagHTML'],
    ['tasksHTML', 'tasksHTML'], ['reportsHTML', 'reportsHTML'], ['settingsHTML', 'settingsHTML'],
    ['autoHTML', 'autoHTML'],   /* v89.218：storyHTML / storiesHTML 随故事系统退役 */
    ['marchBeaconHTML', 'marchBeaconHTML'], ['marchAffairsHTML', 'marchAffairsHTML'],
    ['invasionRulesHTML', 'invasionRulesHTML'], ['beaconFlowHTML', 'beaconFlowHTML'],
  ];
  LIST.forEach(function (it) {
    var fn = G.ui[it[1]];
    if (typeof fn !== 'function') { INV.viol('view-missing', it[0]); return; }
    try {
      var v = fn();
      if (typeof v === 'string' && /NaN|undefined/.test(v)) {
        INV.viol('view-text', it[0] + ' 含 ' + (v.match(/NaN|undefined/) || [''])[0]);
      }
    } catch (e) { noteErr('view.' + it[0], e); }
  });
  /* 自动化面板七个页逐个渲染（v89.118 起含 invasion） */
  (G.ui.AUTO_ITEMS || []).forEach(function (x) {
    try {
      var h = G.ui.autoPaneHTML(x.id);
      if (typeof h === 'string' && /NaN|undefined/.test(h)) INV.viol('view-text', 'pane.' + x.id);
    } catch (e) { noteErr('view.pane.' + x.id, e); }
  });
}

/* ---------- 9. 主循环 ---------- */
var SNAP_EVERY = 96;
var BRAIN_LAST = -1e9;
var T0 = _RealNow();
RUN('主循环启动：每 tick = 1 现实秒 × 600 倍率；快照 1/游戏年；脑决策 ' + '40t(前10min)→120t');

for (tNow = 1; tNow <= MAXT; tNow++) {
  simMs += 1000;
  /* SIM 时钟的日期校验（第 100 tick 打印一次） */
  if (tNow === 100) {
    RUN('SIM 时钟校准：' + simClock() + '（应为 09:01:40 前后）· questDay=' + G.questDayIndex());
    dumpOnce('state', st, 80);
    dumpOnce('city', city0, 80);
    dumpOnce('settings', st.settings, 80);
    dumpOnce('extGrid', (G.extGridOf(city0) || [])[0], 20);
  }
  if (tNow === 600) {
    dumpOnce('quests', st.quests, 30);
    var gl0 = G.gatherList(); if (gl0 && gl0[0]) dumpOnce('gatherRec', gl0[0], 30);
    var mr0 = (st.marches || [])[0]; if (mr0) dumpOnce('marchRec', mr0, 30);
    var gd0 = st.generals[0]; if (gd0) dumpOnce('genRec', gd0, 40);
    var tq0 = (st.queues.train || [])[0]; if (tq0) dumpOnce('trainQ', tq0, 20);
    var qb0 = (st.queues.build || [])[0]; if (qb0) dumpOnce('buildQ', qb0, 20);
    dumpOnce('stats', st.stats, 40);
    dumpOnce('world', st.world, 40);
  }
  safeCall('tickOnce', function () { G.tickOnce(); });
  safeCall('battle.tick', function () { G.battle.tick(1); });
  if (tNow % 10 === 0) safeCall('handleBattles', handleBattles);
  var every = tNow < 600 ? 40 : 120;
  if (tNow - BRAIN_LAST >= every) {
    BRAIN_LAST = tNow;
    safeCall('b.quests', tryQuests);
    safeCall('b.build', tryBuildNew);
    safeCall('b.ext', tryBuildExt);
    safeCall('b.wall', tryWall);
    safeCall('b.train', tryTrain);
    safeCall('b.gather', tryGather);
    safeCall('b.gatherFin', finishRipeGathers);
    safeCall('b.occupy', keepOccupying);
    safeCall('b.withdraw', tryWithdraw);
    safeCall('b.reinforce', tryReinforce);
    safeCall('b.market', tryMarketSell);
    safeCall('b.farm', tryFarm);
    safeCall('b.shop', tryShop);
    safeCall('b.sect', trySect);
    safeCall('b.autoMarch', manageAutoMarch);
    /* v89.92：宝物流优先级 = 最先（这是它的打法本体 —— 旧币先换产量） */
    if (MODE === 'buff' || MODE === 'all') {
      safeCall('b.buffCorvee', buffCorvee);
      safeCall('b.buffAttr', buffAttr);
      safeCall('b.buffProd', buffProd);
    }
    safeCall('b.goldSell', goldSell);
    safeCall('b.goldInn', goldInn);
    safeCall('b.goldBooks', goldBooks);
    safeCall('b.goldRush', goldRush);
    safeCall('b.goldTrainRush', goldTrainRush);
    safeCall('b.goldPoints', goldPoints);
    safeCall('b.goldGuards', goldGuards);
    safeCall('b.goldHerbs', goldHerbs);
    safeCall('b.goldNeigong', goldNeigong);
    safeCall('b.goldLord', goldLord);
    if (MODE === 'equip' || MODE === 'all') {
      safeCall('b.equipForgeUp', equipForgeUp);
      safeCall('b.equipCraft', equipCraft);
      safeCall('b.equipEnhance', equipEnhance);
      safeCall('b.equipWear', equipWear);
    }
    safeCall('b.milestones', execMilestones);
    safeCall('b.v118', driveV89118);            /* v89.118：新功能驱动（收编/沙盘核对/来犯） */
  }
  if (tNow % 240 === 0) safeCall('inv.check', checkInvariants);     /* v89.118：不变量体检 */
  if (tNow % 4800 === 0) safeCall('inv.views', checkViews);          /* v89.118：视图渲染体检 */
  if (tNow % SNAP_EVERY === 0) snapshot();
  if (tNow % 480 === 0) {
    flushEv();
    var perf = (_RealNow() - T0) / 1000;
    RUN('进度 ' + tNow + '/' + MAXT + ' · 第 ' + yNow().toFixed(1) + ' 游戏年 · 用时 ' + perf.toFixed(0) + 's'
      + ' · 城' + st.cities.length + ' · 军 ' + fmtNum(totalArmy()) + ' · 旧币 ' + fmtNum(st.res.gold)
      + ' · 将 ' + st.generals.length + ' · 日志 ' + (EVFLUSHED + EV.length) + ' · 错 ' + ERRN);
    RUN(goldLine() + stratLine());
  }
  if (tNow % 2400 === 0) {
    try { fs.writeFileSync(path.join(OUT, 'checkpoints', 'y' + Math.round(tNow / 96) + '.json'), G.savePayload()); } catch (e) { noteErr('ckpt', e); }
  }
}

/* ---------- 10. 收尾 ---------- */
flushEv(); flushRun();
function errCount() { return ERRN; }
var finalOut = {};
try { finalOut.year = +yNow().toFixed(2); finalOut.army = totalArmy(); finalOut.gold = Math.round(st.res.gold); } catch (e) {}
try { fs.writeFileSync(path.join(OUT, 'final_state.json'), G.savePayload()); } catch (e) { noteErr('final.save', e); }
try { fs.writeFileSync(path.join(OUT, 'errors.json'), JSON.stringify(ERRLIST, null, 1)); } catch (e) { noteErr('errors', e); }
try {
  fs.writeFileSync(path.join(OUT, 'gold_final.json'), JSON.stringify({
    gold: { spends: GOLD.spends, rerolls: GOLD.rerolls, recruits: GOLD.recruits, books: GOLD.booksUsed,
      sold: GOLD.goldSold, sales: GOLD.salesCount, freePts: GOLD.freePts, milestones: GOLD.milestones },
    guards: st.cities.map(function (c) { var g = G.guardGeneralOf(c); return g ? { c: c.name, g: g.name, r: G.rankOf(g).name, lv: g.level, nz: guardNzOf(g) } : null; }),
    gens: (st.generals || []).map(function (g) {
      var a = G.genAttrs(g) || {};
      return { n: g.name, r: G.rankOf(g).name, lv: g.level || 1, nz: Math.round(a.nz || 0), yw: Math.round(a.yw || 0),
        zm: Math.round(a.zm || 0), st: g.status || '', free: Math.round(g.freePts || 0), hero: !!g.hero };
    })
  }, null, 1));
} catch (e) { noteErr('gold.final', e); }
try {
  fs.writeFileSync(path.join(OUT, 'inv_final.json'), JSON.stringify({
    invasion: { warn: INV.invasionWarn, held: INV.invasionHeld, breached: INV.invasionBreached,
      failBeacon: INV.invasionFailBeacon, slotLast: INV.slotLast },
    captive: { conscriptedN: INV.captiveConscripted, popGained: INV.captivePop, runs: INV.conscriptRuns,
      campLeft: (G.captivesTotalOf ? G.captivesTotalOf() : 0) },
    sandbox: { checked: INV.sandboxChecked, noSandbox: INV.defReportNoSbx },
    duelMentions: INV.duelMentions,
    promotes: INV.promotes || 0,
    promoteMsg: INV.promoteMsg || '',
    expandMsg: INV.expandMsg || '',
    npcAtkMsg: INV.npcAtkMsg || '',
    violations: INV.violations, violN: INV.violN
  }, null, 1));
} catch (e) { noteErr('inv.final', e); }
try {
  fs.writeFileSync(path.join(OUT, 'strat_final.json'), JSON.stringify({
    mode: MODE,
    buff: (MODE === 'buff' || MODE === 'all') ? { spend: BUFF.spend, units: BUFF.units, tFirst: BUFF.tFirst } : null,
    equip: (MODE === 'equip' || MODE === 'all') ? { spend: EQUIP.spend, crafted: Object.keys(EQUIP.crafted),
      worn: EQUIP.wornCount, wornGen: EQUIP.wornGen, tCraft1: EQUIP.tCraft1, tCraft12: EQUIP.tCraft12,
      tEnh120: EQUIP.tEnh120, tWorn12: EQUIP.tWorn12,
      enh: ytIds().map(function (x) { var i4 = G.eqFind(x); return { id: x, e: i4 ? G.eqEnhOf(i4) : -1 }; }) } : null,
    guards: st.cities.map(function (c) {
      var gg = G.guardGeneralOf(c);
      return gg ? { c: c.name, g: gg.name, r: G.rankOf(gg).name, lv: gg.level, nz: guardNzOf(gg) } : null;
    })
  }, null, 1));
} catch (e) { noteErr('strat.final', e); }

var errTop = Object.keys(ERRS).map(function (k) { return { k: k, n: ERRS[k].n }; })
  .sort(function (a, b) { return b.n - a.n; }).slice(0, 12);
RUN(goldLine() + stratLine());
RUN('👥 英雄前十：' + (st.generals || []).slice().sort(function (a, b) { return (b.level || 1) - (a.level || 1); }).slice(0, 10).map(function (g) {
  var a = G.genAttrs(g) || {};
  return g.name + '[' + G.rankOf(g).name + ']Lv' + g.level + '(nz' + Math.round(a.nz || 0) + '/yw' + Math.round(a.yw || 0) + ')';
}).join(' · '));
RUN('=== 推演结束 ===');
RUN('终态：第 ' + yNow().toFixed(1) + ' 游戏年 · 城 ' + st.cities.length + ' · 军 ' + fmtNum(totalArmy())
  + ' · 旧币 ' + fmtNum(st.res.gold) + ' · 将 ' + st.generals.length + ' · 战报 ' + (st.reports || []).length + ' 份');
RUN('错误合计 ' + ERRN + ' 次；Top: ' + errTop.map(function (x) { return x.k.slice(0, 60) + '×' + x.n; }).join(' || '));
RUN('输出目录：' + OUT);
flushRun();
console.log('DONE ' + TAG + ' ticks=' + MAXT + ' errs=' + ERRN);
process.exit(0);   /* v89.91：跑完即退（游戏定时器会挂住事件循环） */
